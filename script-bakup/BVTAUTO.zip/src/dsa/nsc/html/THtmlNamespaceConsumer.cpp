/*************************************************************************
*
* THTMLNAMESPACECONSUMER.CPP - NSC wrapper for HTML writer.
*
* Copyright (C) 2006 IBM Corporation
*
*************************************************************************/

#include "TDSAException.h"
#include "TOSSpecific.h"
#include "linkage.h"

#include "TReport.h"
#include "TReport_vmwesxi.h"
#include "TWriter_vmwesxi.h"

#include "THtmlNamespaceConsumer.h"
#include "THtmlWriter.h"
#include "THtmlWriter_vmwesxi.h"
#include <fstream>

namespace NIBMDSA20 {


boost::shared_ptr<THtmlNamespaceConsumer> THtmlNamespaceConsumer::fgInstance = boost::shared_ptr<THtmlNamespaceConsumer>();


void THtmlNamespaceConsumer::Initialize(std::string homePath) {
   fgInstance = boost::shared_ptr<THtmlNamespaceConsumer>(new THtmlNamespaceConsumer(homePath));
}


boost::shared_ptr<THtmlNamespaceConsumer> THtmlNamespaceConsumer::GetInstance() {
   return fgInstance;
}


THtmlNamespaceConsumer::THtmlNamespaceConsumer(std::string homePath)
: fHomePath(homePath) {
}


const std::string &THtmlNamespaceConsumer::GetName(TCIMContext context) const {
   static std::string name = "html";

   return name;
}


// Namespaces.
void THtmlNamespaceConsumer::ConsumeNamespace(boost::shared_ptr<ICIMNamespace> cimNamespace, TCIMContext context)
{
	TCIMContext::iterator iter = context.end();

	TReport report(boost::const_pointer_cast<ICIMNamespace>(cimNamespace), context, fHomePath);
	THtmlWriter writer;

	TReport_vmwesxi report_vmwesxi(boost::const_pointer_cast<ICIMNamespace>(cimNamespace), context, fHomePath);
	THtmlWriter_vmwesxi writer_vmwesxi;

	std::string szNSP = "";
	
	if ((iter = context.find("nsp")) != context.end())
	{
		szNSP = ((*iter).second).ToString();
	}

	if ("vmwesxi" == szNSP)
	{
		report_vmwesxi.Write(&writer_vmwesxi, context);
	}
	else
	{
		report.Write(&writer, context);
	}
	
	std::string diffOutputFile = context["OUTPUT_FILE"].ToString();
	if (!diffOutputFile.empty())
	{
		fDiffSummaryFile.open( diffOutputFile.c_str(), std::ios_base::out );
		if ( ! fDiffSummaryFile ) 
		{ 
			throw TDSAException(TDSAStatusCode::kDSAStatusFileSystemError);
		}
		GenerateDiffSummary(cimNamespace);
		fDiffSummaryFile.close();
	}
}

void THtmlNamespaceConsumer::GenerateDiffSummary(boost::shared_ptr<ICIMNamespace> pNamespace)
{
   fDiffSummaryFile << kHtmlHeader << kHtmlSortScript;;

   // Do qualifer declarations first.
   //pNamespace->EnumerateQualifierDecls(std::bind1st(std::mem_fun(&TXMLWriterImpl::WriteQualifierDecl), this));

   // Now write the class declarations for all children of the root node.
   std::vector<boost::shared_ptr<ICIMClass> > rootClasses;
   pNamespace->EnumerateRootClasses(TAddClassesToVectorCallback(rootClasses));

   /* Defect: 397253
      Owner: zhouxush@cn.ibm.com
	  Desc: Association Classes shall be in front of other classes. So, resort all Classes.
   */
   std::vector<boost::shared_ptr<ICIMClass> > AssoClass;
   std::vector<boost::shared_ptr<ICIMClass> > InstClass;

   for (std::vector<boost::shared_ptr<ICIMClass> >::iterator rootClassIt(rootClasses.begin());
        rootClassIt != rootClasses.end();
		++rootClassIt) {
	  if( (*rootClassIt)->IsAssociation() )
		  AssoClass.push_back(*rootClassIt);
	  else
		  InstClass.push_back(*rootClassIt);
   }

   std::vector<boost::shared_ptr<ICIMClass> > resort_rootClasses(InstClass);
   resort_rootClasses.insert(resort_rootClasses.end(), AssoClass.begin(), AssoClass.end());
/*
   for (std::vector<boost::shared_ptr<ICIMClass> >::iterator rootClassIt(resort_rootClasses.begin());
      rootClassIt != resort_rootClasses.end();
      ++rootClassIt)
   {
      try
      {
         WriteClassAndSubclasses(*rootClassIt);
      }
      catch (...)
      {
         continue;
      }
   }
*/
   // Write all instances differences.
   diffInstancesCount = 0;
   for (std::vector<boost::shared_ptr<ICIMClass> >::iterator rootClassIt(resort_rootClasses.begin());
        rootClassIt != resort_rootClasses.end();
        ++rootClassIt) {
      (*rootClassIt)->EnumerateInstances(std::bind1st(std::mem_fun(&THtmlNamespaceConsumer::WriteDiffInstance), this));
   }

	
	fDiffSummaryFile <<"<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" "
					 << "style=\"word-break:break-all; word-wrap:break-all;\">";
	
	fDiffSummaryFile <<"<tr><td colspan=4 width=\"80%\" style=\"font-family:Arial, Helvetica, verdana, sans-serif; \
						font-size:medium; color: white; background-color:green;\">"; 

	fDiffSummaryFile <<"Totaly " <<diffInstancesCount <<" different instances found!</tr></table>" <<std::endl;
	
	fDiffSummaryFile << kTableFooter <<std::endl;
    fDiffSummaryFile << kHtmlFooter;

	fDiffSummaryFile <<"<!--" <<diffInstancesCount <<"-->";
   
}

bool THtmlNamespaceConsumer::WriteDiffInstance(boost::shared_ptr<ICIMInstance> instance)
{
	if (IsDiffInstance(instance))
   	{
   		++ diffInstancesCount;
		fDiffSummaryFile <<"<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"1\" "
					 << "style=\"word-break:break-all; word-wrap:break-all;\">";

		fDiffSummaryFile <<"<tr><td colspan=4 width=\"80%\" style=\"font-family:Arial, Helvetica, verdana, sans-serif; \
	        				font-size:medium; color: white; background-color:red;\">" 
	        			<<GetInstancePath(instance) <<"</td></tr>"<<std::endl; 
		fDiffSummaryFile << "<tr style=\"background-color: navy; color:white; font-weight: bold;\">"
						<< "<td>PROPERTY NAME</td>"
						<< "<td> Type </td>"
						<< "<td> Current Value </td>"
						<< "<td> Previous Value</td>"
						<< "</tr>" 
						<<std::endl;

		instance->EnumerateProperties(std::bind1st(std::mem_fun(&THtmlNamespaceConsumer::WriteDiffProperty), this));
		
		fDiffSummaryFile << kTableFooter << "<br>" <<std::endl;
   	}

	return true;
}

std::string THtmlNamespaceConsumer::GetInstancePath(boost::shared_ptr<ICIMInstance> instance)
{
	vector<const string *> keys;
	    instance->GetClass()->EnumerateKeyNames(TAddKeyNamesToVectorCallback(keys));
	    TCIMReference ref;

	    ref.SetClass(instance->GetClass());
	    for (vector<const string *>::iterator it = keys.begin(); it != keys.end(); ++it) 
		{
	        ref.AddKeyValue(**it, (instance)->GetProperty(**it)->GetValue());
	    }
	
		return ref.GetPath();
}


bool THtmlNamespaceConsumer::IsDiffInstance(boost::shared_ptr<ICIMInstance> instance)
{
	isDiffInstance = false;

	instance->EnumerateProperties(std::bind1st(std::mem_fun(&THtmlNamespaceConsumer::IsDiffProperty), this));

	return isDiffInstance;
}

bool THtmlNamespaceConsumer::IsDiffProperty(boost::shared_ptr<ICIMProperty> property)
{
	if (isDiffInstance == false && property->IsPrevValueDifferent())
	{	
		
		if (!(property->GetType()==TCIMValue::TCIMType::kBoolean && (property->GetPrevValue().ToString() == property->GetValue().ToString())))
		{
			isDiffInstance = true;
		}
		
	}
	return isDiffInstance;
}

bool THtmlNamespaceConsumer::WriteDiffProperty(boost::shared_ptr<ICIMProperty> property) 
{

	if (!property->IsPrevValueDifferent()/* || (property->GetPrevValue() == property->GetValue())*/)
	{
		return false;
	}

	if (property->GetType()==TCIMValue::TCIMType::kBoolean && (property->GetPrevValue().ToString() == property->GetValue().ToString()))
	{
		return false;
	}

	if (property->GetValue()==property->GetPrevValue())
	{
		property->SetValue(TCIMValue(property->GetType()));
	}

   	const TCIMValue &value = property->GetValue();
	const TCIMValue &prevValue = property->GetPrevValue();

	fDiffSummaryFile << "<tr style=\"background-color: #CCCCCC; \">"
					<<"<td width=\"20%\" style=\"background-color: navy; color:white;\">" <<property->GetDeclaration()->GetName() <<"</td>" << std::endl
					<<"<td width=\"5%\" >" <<property->GetType() <<"</td>" <<std::endl;

	fDiffSummaryFile << "<td width=\"35%\" >" <<std::endl;
   if (!property->GetPropagated()) 
   	{
	
	
	if (!value.IsNull()) 
   {
      if (value.IsArray()) 
	  {

         const std::vector<TCIMValue> &vec = value;
		 fDiffSummaryFile <<" {";
         for (std::vector<TCIMValue>::const_iterator it = vec.begin();
              it != vec.end();
              ++it) {
   			fDiffSummaryFile <<"\"" <<it->ToString()<<"\", " <<std::endl;
         }
		fDiffSummaryFile <<"}";
      }
	  else if (value.GetType() == TCIMValue::TCIMType::kReference) 
	  {
         WriteDiffValueReference(value);
      }
	  else 
	  {
   		fDiffSummaryFile <<value.ToString() <<std::endl;
      }
	}

	fDiffSummaryFile << "</td>";
	fDiffSummaryFile << "<td width=\"35%\">";
/*
	if (property->IsArray()) 
	  	{
            fDiffSummaryFile << "<td width=\"35%\"> ARRAYSIZE=\"" << property->GetValue().GetMaxArraySize()<< "\" " <<std::endl;
      	} 
	  else if (property->GetType() == TCIMValue::TCIMType::kReference) 
	  {
		fDiffSummaryFile << "<td width=\"35%\"> REFERENCECLASS=\"" << property->GetValue().GetReferencedClass()->GetName()<< "\" " <<std::endl;
      } 
	  else 
	  {
         fDiffSummaryFile << "<td width=\"35%\">";
      }
*/
	if (!prevValue.IsNull()) 
	   {
		  if (prevValue.IsArray()) 
		  {
	
			 const std::vector<TCIMValue> &vec = prevValue;
			 fDiffSummaryFile <<" {";
			 for (std::vector<TCIMValue>::const_iterator it = vec.begin();
				  it != vec.end();
				  ++it) {
				  	fDiffSummaryFile <<"\"" <<it->ToString() <<"\", " <<std::endl;
			 }
			fDiffSummaryFile <<"}";
		  }
		  else if (prevValue.GetType() == TCIMValue::TCIMType::kReference) 
		  {
			 WriteDiffValueReference(prevValue);
		  }
		  else 
		  {
			 fDiffSummaryFile <<prevValue.ToString() <<std::endl;
		  }
		}

		fDiffSummaryFile << "</td>";


   }

	fDiffSummaryFile << "</tr>" <<std::endl;

   return true;
}

void THtmlNamespaceConsumer::WriteDiffValueReference(const TCIMValue &value) {
   TCIMReference ref = value;
   TCIMContext keymap;
   ref.EnumerateKeyBindings(TAddKeyBindingsToMapCallback(keymap));
   if (keymap.empty()) {
      // Class only.
      fDiffSummaryFile << "REFERENCECLASS=\"" << ref.GetClassName() << "\"" << endl;
   } else {
      fDiffSummaryFile << "REFERENCECLASS=\"" << ref.GetClassName() << "\"" << endl;

   }
}



//std::string THtmlNamespaceConsumer::GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> pluginNamespace, boost::shared_ptr<ICIMNamespace> cmpiNamespace, const IConsumeProvidersCallback &callback, TCIMContext context){
std::string THtmlNamespaceConsumer::GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> unionNamespace, const IConsumeInstancesCallback &callback, uint32_t dataNeeded, TCIMContext context){
	return "";
}


extern "C" {
// This function is called by TOSSpecific::LoadNSCLibrary
DLLEXPORT INamespaceConsumer *html_CreateINamespaceConsumer() {
   THtmlNamespaceConsumer::Initialize(TOSSpecific::GetDSARootPath());
   return THtmlNamespaceConsumer::GetInstance().get();
}
}


};
