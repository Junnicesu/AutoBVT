#if !defined(_CDATASOURCEVERSION_H)
#define _CDATASOURCEVERSION_H

class CDataSourceVersion
{
public:
	CDataSourceVersion();
	~CDataSourceVersion();
	void Init();	
	void SetVersion(int iMajor, int iMinor, int iBuild);
public:
	int _iMajorVersion;
	int _iMinorVersion;
	int _iBuildVersion;
};

#endif

