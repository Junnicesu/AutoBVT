#include "CDataSourceVersion.h"

CDataSourceVersion::CDataSourceVersion()
{
}

CDataSourceVersion::~CDataSourceVersion()
{
}

void CDataSourceVersion::Init()
{
	_iMajorVersion = 0;
	_iMinorVersion = 0;
	_iBuildVersion = 0;
}

void CDataSourceVersion::SetVersion(int iMajor, int iMinor, int iBuild)
{
	_iMajorVersion = iMajor;
	_iMinorVersion = iMinor;
	_iBuildVersion = iBuild;
}
