/*************************************************************************
*
* DSACLI.CPP - Command line client.
*
* Copyright (C) 2004-2007 IBM Corporation
*
*************************************************************************/
#if FDR_COMPILER == msvc
// Disable these warnings on the MSVC compiler.
#pragma warning(push)
#pragma warning(disable: 4127 4511 4512)
#endif
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#ifndef FDR_OS_WINDOWS
#include "boost/regex.hpp"
#endif
#if FDR_COMPILER == msvc
#pragma warning(pop)
#endif
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>


#if defined(FDR_OS_WINDOWS)
// Bring this in to be able to set the process priority.
#define _WIN32_WINNT 0x0501
#include "windows.h"
#else
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <ctype.h>
#include <ctime>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <errno.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/fcntl.h>
#include <sys/timeb.h>
#include <sys/wait.h>
#endif
#include "dsacli.h"
#include <signal.h>

using namespace std;
using namespace NIBMDSA20;
using namespace boost;

TDsaCli *fgInstance;

std::string dummy="normal";

#define MAX_LINE_LEN 512
// keys[Model][device][partition #][partition type]
char* mediadisks[10];
char* mediapartitions[10][2];
/*
  mediakeys[index][0] = model name
  mediakeys[index][1] = device file
  mediakeys[index][2 - 5] = 4 partitions if existed
 */

char* mediakeys[10][6];
char* mediadeviceModels[10][2];
int mediachosenIndex=-1;
char medialine[MAX_LINE_LEN];
char mediaFILE_SEPARATOR = '/';
int threadFinished=0;
TDsaCli *marshall;
int EnumeratedTest=0;

int main(int argc, char **argv) {
    //signal(SIGQUIT, SIG_IGN);
   marshall = new TDsaCli;
    int ret = marshall->Main(argc, argv);
    delete marshall;
    return ret;
}

TDsaCli::TDsaCli() {
    interactive=false;
    fOEM=false;
    helper = TCIMDataHelper::GetCIMDataHelper();
    if (helper->IsOEM()) {
        fOEM=true;
    }

}
TDsaCli::~TDsaCli() {
    helper->ClearInstances();
    //helper->FreeCIMDataHelper();
}

TDsaCliArgs::TDsaCliArgs() {}

int TDsaCli::Main(int argc, char **argv) {
    fSol=false;
    GetCLIData(argc,argv);
    //RunAutomation();
    //RunInteractive();
    //std::cout<<ExecuteDiagTest("TestControlRegisters",dummy);
    //WaitForKeyAndExit(GetCLIData(argc,argv));
    //return 0;
    _exit(0);
}

int TDsaCli::GetCLIData (int argc, char **argv) {
    if ((argc == 1) || ((argc == 2) && ((argv[1][1] == 0)))) {
        RunInteractive();
        //cout << "The syntax of the command is incorrect.  Use \"dsacli help\" for more information. " << endl;
        return 0;
    }
	
	if (argc >=2 && "-test" == std::string(argv[1]))
	{
		return RunTestMode(argc, argv);
	
	}

    // build arguments
    //CmdLineArguments CLIargs;
    string curArgument;
    try {
        curArgument = string(&argv[1][0]);
        //parsing command line agruments
        //CLIargs = TDsaCliArgs::parse(argc, argv);
    } catch (...) {
        //cout << "  Use \"dsacli help\" for more information. " << endl;
        return(-1);
    }
    // pass client and argument vector to operation handler
    if (curArgument == "auto") {
        //fScriptAddress = string(&argv[2][0]);
        //fScriptPath = string(&argv[3][0]);
        helper->RunAutomation();
    } else if (curArgument == "sol") {
        fSol=true;
        RunInteractive();
    } else
        RunInteractive();
    /*if (CLIargs.command == "collect")
        CollectData();
    else if (CLIargs.command == "interactive")
        RunInteractive();
    else if (CLIargs.command == "gethtml")
        std::cout<<GetHTMLPage(CLIargs.action);
    else if (CLIargs.command == "enumtests"){
        EnumerateDiagTests(dummy);
    }
    else if (CLIargs.command == "enumtestsettings")
        EnumerateTestSettings(dummy);
    else if (CLIargs.command == "exectest"){
        std::cout<<ExecuteDiagTest(CLIargs.action,dummy)<<std::endl;
    }
    else if (CLIargs.command == "getextresult")
        GetExtendedResults(dummy);
    else if (CLIargs.command == "transfer")
        TransferToIBM();
    else if (CLIargs.command == "help")
        cout << usage() << endl;
    else
        cout << "invalid operation" << endl;*/
    return 0;
}


int TDsaCli::RunTestMode(int argc, char **argv)
{
	std::string compare="compare.xml.gz";
	std::string output="DiffSummary.html";
	std::string deltaspec="deltaspec.xml";
	for (int i=2; i<argc; i++)
	{
		std::string currParams=argv[i];
		
		if (currParams.find("compare=")==0)
		{
			compare = currParams.erase(0,8);
		}
		else if (currParams.find("output=")==0)
		{
			output = currParams.erase(0,7);
		}
		else if (currParams.find("deltaspec=")==0)
		{
			deltaspec = currParams.erase(0,10);
		}
	}

	std::fstream fFile;
	fFile.open(compare.c_str(), std::ios_base::in);
	if (!fFile)
	{
		printf("compare file %s not exist!\n", compare.c_str());
		return -1;
	}
	fFile.close();
	fFile.open(deltaspec.c_str(), std::ios_base::in);
	if (!fFile)
	{
		printf("deltaspec file %s not exist!\n", deltaspec.c_str());
		return -1;
	}
	fFile.close();

	printf("compare=%s\n", compare.c_str());
	printf("output=%s\n", output.c_str());
	printf("deltaspec=%s\n", deltaspec.c_str());
	std::vector<std::string> choices;
	choices.push_back("v");
	helper->AddFileToDiff(compare);
	helper->SetTestParams(deltaspec, output);
	helper->Collect(choices);
}

CmdLineArguments TDsaCliArgs::parse(int argc, char * argv[]) {
    CmdLineArguments arguments;
    string curArgument;
    arguments.isDestructiveEnabled = false;
    curArgument = string(&argv[1][0]);
    if (curArgument == "collect" || curArgument == "exectest" || curArgument == "gethtml" || curArgument == "enumtests" || curArgument == "enumtestsettings" || curArgument == "getextresult" || curArgument == "transfer" || curArgument == "help" || "interacive") {
        arguments.command = curArgument;
    } else {
        cout << "The syntax of the command is incorrect.";
        throw 0;
    }
    for (int i = 1; i < argc; i++) {
        curArgument = string(&argv[i][0]);
        if (curArgument == "exectest") {
            arguments.action = string(&argv[++i][0]);
        } else if (curArgument == "gethtml") {
            arguments.action = string(&argv[++i][0]);
        }
    }
    return(arguments);
}

string TDsaCli::usage() {
    ostringstream s;
    s << "Executes IBM DSA using the command line.\n";
    s << "\n";
    s << " dsacli <command> [-options]\n";
    s << "\n";
    s << "   commands:\n";
    s << "     interacive         - Runs in Interactive mode\n";
    s << "     collect            - Runs collectall\n";
    s << "     gethtml            - Gets URL for the HTML or actual source\n";
    s << "     enumtests		- Returns HTML of Test Listing-test centric or device\n";
    s << "     enumtestsettings	- Returns HTML of Test Listing\n";
    s << "     exectest		- Returns HTML of basic result\n";
    s << "     getextresult	- Returns HTML of extended result (eg message log)\n";
    s << "     transfer		- Transfers to IBM\n";
    s << "     copy			- Copy DSA results to removable media.\n";
    s << "     help               - Displays this message\n";
    s << "     quit               - Exit the Utility\n";
    s << "\n";
    s << "   options:\n";
    s << "     <testname>        - Specifies the testname for the \"exectest\" commmand\n";
    //s << "     -t <test>          - Specifies a test for the \"run\" commmand\n";
    //s << "     -x                 - Enables the execution of destructive tests\n";
    s << "\n";
    s << "IBM DSA Command Line Interface (c) IBM Corporation, 2003-2007" << endl;
    return(s.str());
}

string TDsaCli::Interusage() {
    ostringstream s;
    if (!fOEM) {
        s << "IBM DSA Interactive.\n\n";
    } else {
        s << "DSA Interactive.\n\n";
    }
    s << "1 - Data Collection.\n";
    s << "2 - Diagnostics.\n";
    //s << "    (Note: To exit viewer, type :x or ZZ then press enter)\n";
    s << "3 - Copy Collected System Information to Local Media.\n";

    if (!fOEM) {
        s << "4 - Send Collected System Information to IBM Server or Customized FTP server.\n";
        /* determine whether support update function, and then show or unshow update menu.*/
//if  (helper->HelperUpdateIsSupport()==0)
        if  (0) { /*not to show update function*/
            s << "5 - Update.\n";
            s << "6 - Quit and back to main menu.\n";
        } else {
            s << "5 - Quit and back to main menu.\n";
        }

    } else {
        s << "4 - Quit and back to main menu.\n";
    }
    s << "\n";

    return(s.str());
}

string TDsaCli::CollectOptionsChoice() {
    ostringstream s;
    s << "Customize Options\n";
    //s << "Y/N ? ";
    return(s.str());
}

string TDsaCli::CollectOptions() {
    ostringstream s;
    s <<"\nOptions:\n";
    //s <<"-?, -h     	Display help for DSA command-line options.\n";
    s <<"-x         	Do not create a compressed XML file.\n";
    s <<"-v         	Create HTML output files.\n";
    //s <<"-b         	Run in batch mode.\n";
    //s <<"-u:<dir>   	Path to UpdateXpress CD or CD image.\n";
    //s <<"-f         	Collect the full ISMP log.\n";
    s <<"-dumpxml   	Write the DSA .xml.gz file after each plugin runs.\n";
    //s <<"-r <file>\n";
    //s <<"           	Run the CIM difference engine comparing the collected or\n";
    //s <<"           	specified (via -i) data to this file.\n";
    s <<"\nNote: All options must be separated with a comma (Example: -v,-dumpxml)\n";
    //s <<"\nEnter Options: ";
    return(s.str());
}

void TDsaCli::CaptureConsole(std::string conmsg) {
    if (fConsoleFile.is_open())
        fConsoleFile << conmsg << std::flush;
    std::cout << conmsg << std::flush;
}

void TDsaCli::WaitForKeyAndExit(int rc) {
    if (rc == 0)
        CaptureConsole("\nDSACLI completed successfully.  ");
    if (fConsoleFile.is_open()) {
        // Delete the console capture file before exiting.
        fConsoleFile.close();
        ::remove(fConFileName.c_str());
    }
    exit(rc);
}

string TDsaCli::GetHTMLPage(string pageID) {
    return helper->GetHTMLPage(pageID);
}

string TDsaCli::EnumerateDiagTests(string view) {
    if (!interactive) {
        return helper->EnumerateDiagTests(view);
    }
    return helper->EnumerateDiagTests(view,true);
}

string TDsaCli::EnumerateTestSettings(string testID) {
    if (!interactive) {
        return helper->EnumerateTestSettings(testID);
    }
    return helper->EnumerateTestSettings(testID,true);
}

string TDsaCli::ExecuteDiagTest(string testID, string settingData) {
    if (!interactive) {
        return helper->ExecuteDiagTest(testID,settingData);
    }
    return helper->ExecuteDiagTest(testID,settingData,true);
}

string TDsaCli::GetExtendedResults(string testID) {
    if (!interactive) {
        return helper->GetExtendedResults(testID);
    }
    return helper->GetExtendedResults(testID,true);
}

void TDsaCli::CollectData() {
    std::string selection;
    std::cout<<CollectOptionsChoice();

    //set LD_LIBRARY_PATH for qlogic plugin
#if !defined(FDR_OS_WINDOWS) //linux
    setenv("LD_LIBRARY_PATH","./:./qlogic/:./fibre/:./lsi_mir/:$LD_LIBRARY_PATH", 1);
#endif

    do {
        std::cin.clear();
        selection.clear();
        std::cout<< "Y/N ? ";
        std::getline(cin,selection);
        if (fSol) {
            if (selection.empty()) {
                std::getline(cin,selection);
            }
        }
    } while (selection.empty());
    if (selection=="n" || selection=="N") {
        helper->Collect();
    } else if (selection=="y" || selection=="Y") {
        bool validOption = false;
        std::vector<std::string> choices;

        while (!validOption) {
            std::cout<<CollectOptions();

            do {
                std::cin.clear();
                selection.clear();
                std::cout<<"\nEnter Options: ";
                std::getline(cin,selection);
                if (fSol) {
                    if (selection.empty()) {
                        std::getline(cin,selection);
                    }
                }
            } while (selection.empty());

            choices = helper->ParseChoice(selection + ",");
            for (vector<string>::iterator chooseIt = choices.begin();
                    chooseIt != choices.end(); ++chooseIt) {

                string choice = *chooseIt;
                if (choice =="x" || choice =="v" || choice =="dumpxml" || choice == "debug")
                    validOption = true;
            }

            if (!validOption) {
                std::cout<<"Invalid Option"<<std::endl<<std::endl;
            }
        }
        helper->Collect(choices);
    } else {
        std::cout<<"Invalid Option"<<std::endl<<std::endl;
    }
}

void TDsaCli::TransferToIBM() {
    helper->TransferToIBM();
}

void TDsaCli::TransferToUserFTP() {
#ifndef FDR_OS_WINDOWS
    std::string ftpaddress="testcase.boulder.ibm.com";
    int portnum=21;
    std::string input;
    //0: valid, 1: invalid
    int invalidinput;

    //customer ftp address
    do {
        invalidinput=1;
        input.clear();
        std::cout << "Enter Your FTP Address: (i.e: ftp://9.198.23.90/.....)" << std::endl;
        std::cout << "Only anonymous is support" << std::endl;
        std::cout << "Back To Main Menu, Press '#'" << std::endl;
        getline(cin, input);
        if (fSol) {
            if (input.empty()) {
                std::getline(cin, input);
            }
        }
        if (input == "#")
            return;
        //regex expression("((ftp)|(FTP))\\:\\/\\/((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)((\\/$)|(\\/\\w(!\\/)*))");
        regex expression("((ftp)|(FTP))\\:\\/\\/((2[0-4]\\d|25[0-5]|[01]?\\d\\d?)\\.){3}(2[0-4]\\d|25[0-5]|[01]?\\d\\d?)(($)|(\\/$)|(\\/\\w*\\/?))");
        //regex expression("^((FTP|ftp)\\:\\/\\/((\\[?(\\d{1,3}\\.){3}\\d{1,3}\\]?)|(([-a-zA-Z0-9]+\\.)+[a-zA-Z]{2,4}))");
        cmatch regexwhat;
        if (regex_match(input.c_str(),regexwhat,expression)) {
            ftpaddress = input;
            invalidinput = 0;
        } else {
            std::cout << "Invalid FTP format" << std::endl;
            std::cout << std::endl;
        }
    } while (input.empty()||invalidinput==1);

    //port number
    do {
        invalidinput=1;
        input.clear();
        std::cout << "Enter Your FTP Port Number(1 - 65535): (default 21)" << std::endl;
        std::cout << "Back To Main Menu, Press '#'" << std::endl;
        do {
            getline(cin, input);
            if (fSol) {
                if (input.empty()) {
                    std::getline(cin, input);
                }
            }
        } while (input.empty());
        if (input == "#")
            return;
        std::stringstream inputpool;
        int inputport=0;
        inputpool << input;
        inputpool >> inputport;
        if (inputport<1||inputport>65535||!std::cin) {
            std::cout << "Invalid FTP Port Number" << std::endl;
            std::cout << std::endl;
        } else {
            invalidinput=0;
            portnum = inputport;
        }
    } while (invalidinput==1);

    std::cout << "Transfer collected data to User defined ftp server ..." << std::endl;
    std::cout << "Address: " << ftpaddress << std::endl;
    std::cout << "Port: " << portnum << std::endl;
    std::cout << helper->TransferToUserFTP(ftpaddress, portnum) << std::endl;
#endif
}

void TDsaCli::DSAei(std::string classNameIn) {
    helper->DSAei(classNameIn);
}


inline int getSelection(const bool fSold) {
	std::string input = "";
    bool lastLineEmpty = false;
	int selection = 0;
	do{
		std::stringstream mainInput;
		std::cin.clear();
		selection = 0;
		input.clear();
        if (lastLineEmpty == false) {
		    std::cout << "Enter Number: ";
        }
        std::getline(cin, input);
        lastLineEmpty = input.empty();
		if(fSold){
			if(input.empty()){
				std::getline(cin,input);
			}
		}
		mainInput << input;
		mainInput >> selection;
	} while (input.empty());
	return selection;
}


string TDsaCli::SubDataCollectionUsage() {
    ostringstream s;

    s << "\n";
    s << "Data Collection: \n\n";
    s << "1 - Collect System Information.\n";
    s << "2 - View Collected Results.\n";
    s << "      (Note: To exit viewer, type :q or ZZ then press enter)\n";
    s << "3 - Quit to previous menu.\n\n";

    return (s.str());

}
void TDsaCli::SubDataCollection() {
    int selection=0;
    for (;;) {
        std::cout << SubDataCollectionUsage();

        selection = getSelection(fSol);

        if (selection >0 && selection <4) {
            switch (selection) {
            case 1://do data collection
                CollectData();
                break;
            case 2://view the result
                View();
                break;
            case 3://goes back to previous menu
                return;
            default://
                break;
            }
        } else {
            std::cout<<"Invalid Option"<<std::endl<<std::endl;
        }

    }

}


string TDsaCli::SubDiagnosticUsage() {
    ostringstream s;

    s << "\n";
    s << "Diagnostics: \n\n";
    s << "1 - Enumerate Available Diagnostic Tests.\n";
    s << "2 - Execute Diagnostic Test.\n";
    s << "3 - Get Diagnostic Extend Results.\n";
    s << "4 - Quit to previous menu.\n\n";

    return (s.str());
}

bool TDsaCli::SubDiagnosticBuildTapeRWTestParam(int &tapeRWLBA, int &tapeRWBSP, std::string devId) {
    std::string input;

    tapeRWLBA = 0;
    tapeRWBSP = 1;

    int LBLen = 0;
    int startpoint = 0;
    std::stringstream ssMaxDisp;
    int iMax = 1048575;// =0x7FFFFFFF/2048
    int iMax_1 = 1048574;// 2TB - 1

    FILE *fd;
    char line[80];
    fd = fopen("tapeCap.tmp", "r");
    if (fd != NULL) {
        if (fgets(line,sizeof(line), fd) != NULL) {
            std::string settingData(line);
            int devSPos = settingData.find(devId);
            if (devSPos != std::string::npos) {
                devSPos = settingData.find(" : ", devSPos);
                devSPos += 3;
                int devEPos = settingData.find("|", devSPos);
                if (devEPos == std::string::npos) {
                    devEPos = settingData.size();
                }
                settingData = settingData.substr(devSPos, devEPos - devSPos);
                std::stringstream ssVal;
                ssVal << settingData;
                ssVal >> LBLen;
            }
        }
        fclose(fd);
    }

    ssMaxDisp.str("");
    if (LBLen == 0) {
        //std::cout<<"\nNotes: This tape not support GetCapacity command. Please ensure tape range is valid.\n";
        //ssMaxDisp << "Max-1)MB: ";
        std::cout<<"\nNo medium or not support RW test in "<<devId<<". Please check again.\n";
        return false;
    } else {
        iMax = LBLen;
        iMax_1 = LBLen - 1;
        ssMaxDisp << iMax_1 << ")MB: ";
    }

    bool isValid = false;

#if 0
    // according to Martin's suggestion, startpoint is always 0
    // input Range of Tape startpoint
    do {
        input.clear();
        std::cout<<"Range of Tape from (0 - "<<ssMaxDisp.str();
        getline(cin, input);
        if (fSol) {
            if (input.empty()) {
                std::getline(cin,input);
            }
        }
        int iInput = 0;
        std::stringstream ssCheck;
        ssCheck << input;
        ssCheck >> iInput;
        if (iInput >= 0 && iInput <= iMax_1) {
            isValid = true;
            startpoint = iInput;
            // match to logical block address
            iInput *= 2048; // LBA = iInmput * 2^20 / 512
            std::stringstream ssUI;
            ssUI << iInput;
            ssUI >> tapeRWLBA;
        } else {
            std::cout<<"Invalid Number! Please input again\n";
        }
    } while (!isValid);
#endif

    ssMaxDisp.str("");
    ssMaxDisp << 1;
    if (LBLen == 0) {
        ssMaxDisp << " - Max)MB: ";
    } else {
        ssMaxDisp << " - "<< iMax << ")MB: ";
    }

    isValid = false;
    // input Range of Tape endpoint
    input.clear();
    std::cout<<"Enter the quantity of MB you want to test for tape "<<devId<<" (\"full\" is to test the complete cartridge):";
    cin>>input;
    if (input.find_first_of("0123456789") != string::npos) {
        isValid = true;
    }

    int iInput = 0;
    std::stringstream ssCheck;
    if (!isValid) {
        iInput = iMax;
    } else {
        ssCheck << input;
        ssCheck >> iInput;
    }
    if (iInput < startpoint || iInput > iMax) {
        iInput = iMax;
    }
    int BSP = (iInput - startpoint) * 2048;
    tapeRWBSP = BSP;

    int diagsTime = BSP/122880; // 1M = 1 sec
    if (diagsTime == 0)
        diagsTime = 1;

    std::cout<<"RW test for tape "<<devId<<" will take approximately "<<diagsTime<<" minutes and will overwrite any data on the tape media. ";
    std::cout<<"Are you sure you want to continue. Y/N?";

    input.clear();
    cin>>input;
    if (input.empty()) {
        cin>>input;
    }
    if (input == "N" || input == "n") {
        return false;
    }

    return true;
}

void TDsaCli::SubDiagnosticExecute() {
    std::string input;

    int testNumber = 0;
    do {
        helper->GetTestVector()->clear();
        if (EnumeratedTest==0) {
            InitialThread();
        }
        helper->ListTests(helper->ParseTests(EnumerateDiagTests(dummy)));
        int testSize = helper->GetTestVector()->size();

        int vectorHalf = testSize/2;
        if ((int)testSize<=vectorHalf*2) {
            int maxLine=50;
            for (int k=0; k<maxLine; k++) {
                std::cout<<" ";
            }
        }
        if (testSize == 0)
            std::cout<<"No available Tests for this machine"<<std::endl;
        else
            std::cout<<testSize+1<<" Run All Tests"<<std::endl;
        std::cout<<"--------------------------------------------------------------------------------------------------\n";
        //Get the test number user selected
        do {
            input.clear();
            std::cout<<"Enter Number (type x to exit): ";
            getline(cin, input);
            if (fSol) {
                if (input.empty()) {
                    std::getline(cin,input);
                }
            }
        } while (input.empty());
        std::stringstream testInput;
        testInput << input;
        testInput >> testNumber;
        //Get USER input of test want to execute
        if ((!input.empty()) && (input != "x") && (input != "X")) {
            if (testNumber > testSize+1 || (testNumber <=0) || !std::cin) {
                std::cout << "Invalid Test\n";
            } else { //valid test or run all test
                typedef pair <int, int> Int_Pair;
                bool doTapeRWDiags = true;

                int tapeRWLBA;
                int tapeRWBSP;
                map<int, int> flagDoTapeRWDiags;
                map<int, int> mapTapeRWBSP;
                //get parameters for tape RW test
                if (testNumber == testSize+1) { //run all test
                    //To see if we have tape rw test list
                    bool showTapeRWHint = false;
                    std::vector<std::vector<std::string> > TestVector = *helper->GetTestVector();
                    for (int vIndex = 0; vIndex<TestVector.size(); vIndex++) {
                        if ((TestVector[vIndex].begin()[0]).find("RW Test")!=std::string::npos) {
                            std::string devId = TestVector[vIndex].begin()[1];
                            if (!showTapeRWHint) {
                                std::cout << "A tape quantity(MB) parameter is needed for all available Tape RW test" <<std::endl;
                                showTapeRWHint = true;
                            }
                            doTapeRWDiags = SubDiagnosticBuildTapeRWTestParam(tapeRWLBA,tapeRWBSP,devId);
                            if (doTapeRWDiags) {
                                flagDoTapeRWDiags.insert(Int_Pair(vIndex, 1));
                                mapTapeRWBSP.insert(Int_Pair(vIndex, tapeRWBSP));
                            }
                        }
                    }
                } else { //run a single test
                    if (((*helper->GetTestVector())[testNumber - 1].begin()[0]).find("RW Test")!=std::string::npos) {
                        std::string devId = ((*helper->GetTestVector())[testNumber-1]).begin()[1];
                        doTapeRWDiags = SubDiagnosticBuildTapeRWTestParam(tapeRWLBA,tapeRWBSP,devId);
                        if (doTapeRWDiags) {
                            flagDoTapeRWDiags.insert(Int_Pair(testNumber - 1, 1));
                            mapTapeRWBSP.insert(Int_Pair(testNumber - 1, tapeRWBSP));
                        } else {
                            continue;
                        }
                    }
                }

                do {
                    input.clear();
                    if (testNumber == testSize+1)//run all test
                    {//must find out if BMC test in test list
                        bool foundBMCI2Ctest = false;
                        bool foundRWtest = false;
                        int onceCount = 0;
                        std::string onceTest;
                        std::vector<std::vector<std::string> > TestV = *helper->GetTestVector();
                        for (int vIndex = 0; vIndex<TestV.size(); vIndex++) {
                            if (!foundBMCI2Ctest && (TestV[vIndex].begin()[0]).find("I2C Test")!=std::string::npos) {//tell user BMC I2C Test is selected, so for this test, run 1 time only
                                if (0 == onceCount)
                                    onceTest = "'I2C Test'";
                                else
                                    onceTest += " & 'I2C Test'";
                                foundBMCI2Ctest = true;
                                onceCount++;
                            }
                            if (!foundRWtest && (flagDoTapeRWDiags.size()>0) && (TestV[vIndex].begin()[0]).find("RW Test")!=std::string::npos) {//tell user Tape RW Test is selected, so for this test, run 1 time only
                                if (0 == onceCount)
                                    onceTest = "'Tape RW Test'";
                                else
                                    onceTest += " & 'Tape RW Test'";
                                onceCount++;
                                foundRWtest = true;
                            }
                        }
                        if (1 == onceCount) {
                            std::cout << onceTest << " is involved in all test." << std::endl;
                            std::cout << onceTest << " will only execute once, user still can specify loops for the rest tests." << std::endl;
                        } else if (onceCount > 1) {
                            std::cout << onceTest << " are involved in all test." << std::endl;

                            std::cout << onceTest << " will only execute once, user still can specify loops for the rest tests." << std::endl;
                        }
                    }
                    //it is running single test
                    else if ( (*helper->GetTestVector())[testNumber - 1].begin()[0].find("I2C Test") != std::string::npos) {// Looping is not supported for the BMC I2C Test
                        input = "1";
                    }
                    //it is running single test
                    else if ( (*helper->GetTestVector())[testNumber - 1].begin()[0].find("RW Test") != std::string::npos) {// Looping is not supported for the tape RW test Test
                        input = "1";
                    }

                    if (input.empty()) {
                        std::cout<<"Number of Loops (1-25): ";
                        cin>>input;
                        if (fSol) {
                            if (input.empty()) {
                                cin>>input;
                            }
                        }
                    }
                } while (input.empty());
                std::stringstream numLoops;
                int loopCount=0;
                numLoops << input;
                numLoops >> loopCount;
                if (loopCount > 0 && loopCount <=25) { // This is a valid test number to execute
                    int  allTests = 0, runall=0;
                    std::string TestName;
                    std::string DeviceName;

                    if (testNumber == testSize+1) { //User select to run all test
                        allTests = (*helper->GetTestVector()).size();
                        runall = 1;
                    } else
                        allTests = 1;
                    //std::cout << "The allTest = " << allTests << std::endl;
                    for (int i=1; i<=loopCount; i++) {
                        for (int allloop = 0; allloop<allTests; allloop++) {
                            int trueIndex = 0;
                            if (allTests == 1&&runall!=1) { //not run all test
                                trueIndex = testNumber - 1;
                            } else { //run all test
                                trueIndex = allloop;
                            }
                            //std::cout << "The trueIndex = " << trueIndex << std::endl;
                            TestName = (*helper->GetTestVector())[trueIndex].begin()[0];
                            DeviceName = (*helper->GetTestVector())[trueIndex].begin()[1];
                            if (TestName.find("RW Test")!=std::string::npos) {
                                if ((i>1) || flagDoTapeRWDiags.count(trueIndex) == 0)
                                    continue;
                            }

                            if (((TestName == "BMC I2C Test")||(TestName == "IMM I2C Test"))&& (i>1)) {//BMC I2C is not support loop test
                                // std::cout<<"Looping is not supported for the BMC I2C Test"<<std::endl;
                                continue;
                            }
                            std::cout<< "Running " << TestName << " for " << DeviceName << std::endl;
                            if ((TestName == "BMC I2C Test" || TestName == "IMM I2C Test" ) || TestName.find("RW Test")!=std::string::npos)
                                std::cout<<"Test "<<i<<" of "<<1<<std::endl;
                            else
                                std::cout<<"Test "<<i<<" of "<<loopCount<<std::endl;
                            //if(TestName.find("Tape Drive")!=std::string::npos)
                            if (TestName.find("RW Test")!=std::string::npos) {
                                std::string strParam;
                                std::stringstream ssBSP;
                                ssBSP<<mapTapeRWBSP[trueIndex];
                                strParam = (*helper->GetTestVector())[trueIndex].begin()[2] + " : Tape RW Test|" + "0" + "|" + ssBSP.str();
                                std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[trueIndex]).begin()[0]+","+((*helper->GetTestVector())[trueIndex]).begin()[1]+","+((*helper->GetTestVector())[trueIndex]).begin()[2], strParam)<<std::endl<<std::endl;
                            } else
                                std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[trueIndex]).begin()[0]+","+((*helper->GetTestVector())[trueIndex]).begin()[1]+","+((*helper->GetTestVector())[trueIndex]).begin()[2],dummy)<<std::endl<<std::endl;

                        }
                    }
                    std::cout<< "Press Enter To Continue...";
                    runall=0;
                    getchar();
                } else {
                    std::cout<<"Invalid Number\n";
                }

                input.clear();
                testNumber = 0;
            }
        }

    } while ((input != "x") && (input != "X"));
    std::cout << std::endl;
}

void TDsaCli::SubDiagnosticExtendResult() {
    std::string input;
    int testNumber = 0;
    do {
        testNumber = 0;
        helper->GetTestVector()->clear();
        if (EnumeratedTest==0) {
            InitialThread();
        }
        helper->ListTests(helper->ParseTests(EnumerateDiagTests(dummy)));
        std::cout << std::endl;
        std::cout<<"--------------------------------------------------------------------------------------------------\n";
        do {
            input.clear();
            std::cout<<"Enter Number (type x to exit): ";
            getline(cin, input);
            if (fSol) {
                if (input.empty()) {
                    std::getline(cin,input);
                }
            }

        } while (input.empty());
        std::stringstream resultInput;
        resultInput << input;
        resultInput >> testNumber;
        if ((!input.empty()) && (input != "x") && (input != "X")) {
            if ((int)testNumber > helper->GetTestVector()->size() || (testNumber <=0) || !std::cin) {
                std::cout<<"Invalid Test\n";
            } else {
                std::cout<<std::endl;
                std::cout<<GetExtendedResults(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2])<<std::endl<<std::endl;
                std::cout<< "Press Enter To Continue...";
                getchar();
            }
        }
    } while ((input != "x") && (input != "X"));
    std::cout<<std::endl;
}


void TDsaCli::SubDiagnostic() {
    int selection=0;
    for (;;) {
        std::cout << SubDiagnosticUsage();

        selection = getSelection(fSol);

        if (selection >0 && selection <5) {
            switch (selection) {
            case 1://List available diagnostic tests
                helper->GetTestVector()->clear();
                if (EnumeratedTest==0) {
                    InitialThread();
                }
                helper->ListTests(helper->ParseTests(EnumerateDiagTests(dummy)));
                std::cout<<std::endl;
                std::cout<<"--------------------------------------------------------------------------------------------------\n";
                break;
            case 2://Execute diagnostic test
                SubDiagnosticExecute();
                break;
            case 3://Get Extended Result
                SubDiagnosticExtendResult();
                break;
            case 4://goes back to previous menu
                return;
            default://
                break;
            }
        } else {
            std::cout<<"Invalid Option"<<std::endl<<std::endl;
        }

    }

}


int TDsaCli::SubCopyDetermineMedia() {
#ifndef FDR_OS_WINDOWS
    int validSelection=0;
    int fd;
    char buf[8192];
    int rc;
    char *manufacturer;
    int bufferIndex=0;
    int bufferSize;
    int lineIndex=0;
    int copyIndex=0;
    int resetNumber;
    char *modelString = "Model:";
    char *devString = "Device File:";
    char *hwString = "Hardware Class: disk";
    char *venString = "Vendor: usb";
    char *devHexString = "Device: usb";
    char* modelDest;
    int modelDest_len;
    char* devDest;
    int devDest_len;
    char* devHexDest;
    int devHexDest_len;
    char* hwDest;
    int hwDest_len;
    char* venDest;
    int venDest_len;
    char* hwValue;
    char* modelValue = NULL;
    char* deviceValue = NULL;
    char* devHexValue = NULL;
    char* vendorHexValue = NULL;
    int foundModel=0;
    int foundDevice=0;
    int foundDeviceHex=0;
    int foundHW=0;
    int foundVendor=0;
    int i,len;
    char str[80];
    int index1=0;

    int venNum,devNum;
    system("hwinfo --usb > /tmp/usbinfo.txt 2>&1");
    fd = open("/tmp/usbinfo.txt",O_RDONLY);
    if (fd <= 0) {
        std::cout << "Failed opening usb information file." << std::endl;
        return 1;
    }
    rc = read(fd, buf, sizeof(buf));
    close(fd);
    bufferSize = strlen(buf);
    system("rm -f /tmp/usbinfo.txt");
    if (rc <= 0) {
        std::cout << "Failed reading usb information file." << std::endl;
        return 1;
    }
    //Begin looping the file generated
    while (bufferIndex < bufferSize) {
        while ((bufferIndex < bufferSize)&& (buf[bufferIndex] != '\n')) {
            bufferIndex++;
        }
        while ((copyIndex < bufferIndex) && (lineIndex < MAX_LINE_LEN)) {
            if ((MAX_LINE_LEN-1)!=lineIndex) {
                medialine[lineIndex]=buf[copyIndex];
                copyIndex++;
                lineIndex++;
            }
        }
        bufferIndex++;
        copyIndex++;
        lineIndex=0;
        //Look for Hardware Class
        hwDest = strstr(medialine, hwString);
        modelDest = strstr(medialine, modelString);
        devDest = strstr(medialine, devString);
        devHexDest = strstr(medialine, devHexString);
        venDest = strstr(medialine, venString);

        if ( hwDest == NULL) {
            hwDest = strstr(medialine,"Hardware Class: floppy");
        }

        if ( hwDest != NULL ) {
            foundHW = 1;
        }
        //Look for Vendor
        else if ( venDest != NULL ) {
            venDest_len = strlen(venDest);
            vendorHexValue = (char *)malloc (venDest_len);
            if (vendorHexValue!=NULL) {
                //copy after usb
                strcpy(vendorHexValue, venDest+12);
                //strip out everything in quotes
                len = strlen(vendorHexValue) -1;
                for (i=0; i<len; i++) {
                    if (vendorHexValue[i] == 34) {
                        vendorHexValue[i] = 0;
                    }
                }
                //strip the endline
                vendorHexValue[strlen(vendorHexValue) -1] = 0;
                foundVendor = 1;
            }
        }
        //Look for Device Hex info
        else if ( devHexDest != NULL ) {
            devHexDest_len = strlen(devHexDest);
            devHexValue = (char *)malloc (devHexDest_len);
            if (devHexValue!=NULL) {
                //copy after usb
                strcpy(devHexValue, devHexDest+12);
                //strip out everything in quotes
                len = strlen(devHexValue) -1;
                for (i=0; i<len; i++) {
                    if (devHexValue[i] == 34) {
                        devHexValue[i] = 0;
                    }
                }
                //strip the endline
                devHexValue[strlen(devHexValue)-1] = 0;
                foundDeviceHex = 1;
            }
        }
        //Look for Model
        else if ( modelDest != NULL ) {
            modelDest_len = strlen(modelDest);
            modelValue = (char *)malloc (modelDest_len);
            if (modelValue!=NULL) {
                //copy after leading quote
                strcpy(modelValue, modelDest+8);
                //strip the endline
                modelValue[strlen(modelValue) -1] = 0;
                //strip the last quote
                modelValue[strlen(modelValue) -1] = 0;
                foundModel = 1;
            }
        }
        //Look for Device File
        else if ( devDest != NULL ) {
            devDest_len = strlen(devDest);
            deviceValue = (char *)malloc (devDest_len);
            if (deviceValue!=NULL) {
                strcpy(deviceValue, devDest+13);
                //strip out everything in brackets
                len = strlen(deviceValue) -1;
                for (i=0; i<len; i++) {
                    if (deviceValue[i] == 40) {
                        deviceValue[i] = 0;
                    }
                }
                //strip the endline
                deviceValue[strlen(deviceValue) -1] = 0;
                //strcat(deviceValue,"1");
                foundDevice = 1;
            }
        }
        //If all 3 values are 1, we have a match
        if ((foundModel == 1) && (foundDevice == 1) && (foundHW == 1) && (foundVendor == 1) && (foundDeviceHex == 1)) {
            foundModel = 0;
            foundDevice = 0;
            foundDeviceHex = 0;
            foundHW = 0;
            foundVendor = 0;
            if (index1<10) {
                if (strcmp(devHexValue,"0xfada")!=0 && strcmp(vendorHexValue,"0x0483")!=0 && strcmp(vendorHexValue,"0x04b3")!=0) {
                    mediakeys[index1][0]=modelValue;
                    mediakeys[index1][1]=deviceValue;
                    //printf("Model: %s\n",keys[index1][0]);
                    //printf("Device: %s\n",keys[index1][1]);
                    //printf("Device ID: %s\n",devHexValue);
                    //printf("Vendor ID: %s\n",vendorHexValue);
                    SubCopyOrgnizePartition(index1,deviceValue);
                    index1++;
                }
                //else{
                //   printf("Cant Use:\n");
                //   printf("Device ID: %s\n",devHexValue);
                //   printf("Vendor ID: %s\n",vendorHexValue);

                //}
            }
        }
        //reset the line
        for (resetNumber=0; resetNumber<MAX_LINE_LEN; resetNumber++) {
            medialine[resetNumber] = 0;
        }
    }
    if (index1>0) {
        do {
            for (i=0; i<index1; i++) {
                //printf("%i: %s\n",i+1,mediakeys[i][0]);
                std::cout << i+1 << ": " << mediakeys[i][0] << " : "  << mediakeys[i][1] << std::endl;
                //printf("%i:%s\n",keys[i][1]);
            }
            std::cout << "Enter Number (type x to exit): " << std::endl;
            fgets(str,10,stdin);
            i=strlen(str)-1;
            if (str[i]=='\n') {
                str[i]='\0';
            }
            if ((strcmp(str,"X")==0) || (strcmp(str,"x")==0)) {
                return 2;
            }
            i = atoi (str);
            if (i<index1+1&&i>=1) {
                validSelection = 1;
            } else {
                std::cout << "InvalidSelection." << std::endl;
            }
        } while (validSelection==0);
        //printf("You Chose: %s\n",keys[i][0]);
        mediachosenIndex = i-1;
        return 0;
    }
    return 1;
#else
	return 0;
#endif
}

int TDsaCli::SubCopyOrgnizePartition(int index1, char * deviceValue) {
    char cmdbuf[256];
    int index = 1;
    sprintf(cmdbuf,"fdisk -l 2>/dev/null|grep %s |awk '{print $1}'>/tmp/usbdevice.txt", deviceValue);
    // execute twice to ensure no weird characters on some systems(e.g. /dev/sda2y"y"y")
    system(cmdbuf);
    system(cmdbuf);
    string line;
    ifstream input("/tmp/usbdevice.txt",ios::in);

    while (!input.eof()) {
        getline(input,line);
        if (line.find(deviceValue)!=string::npos) {
            index++;
            if (index>5)
                break;
            mediakeys[index1][index] = (char *)malloc(strlen(line.c_str()));
            memcpy(mediakeys[index1][index],line.c_str(),strlen(line.c_str()));
        }
    }
    input.close();
    /*
    for(int i=0;i<6;i++)
    	printf("partition %s\n", mediakeys[index1][i]);
    */

    return 1;

}


int TDsaCli::SubCopyCopyFile(std::string src, std::string dst) {
    char cmd[512];

    sprintf(cmd, "cp %s %s", src.c_str(), dst.c_str());
    return 0 == system(cmd);
}

int TDsaCli::SubCopyCopyTree(std::string src, std::string dst) {
    char cmd[512];

    sprintf(cmd, "cp -r %s %s", src.c_str(), dst.c_str());
    return 0 == system(cmd);
}

int TDsaCli::SubCopyMountMedia(std::string dev, std::string &dstPath) {
#ifndef FDR_OS_WINDOWS
    int found = 0;
    int rc;
    char mount[256];


    int i=2;

    std::string mountdir="/tmp/key";

    if (!dirExists(mountdir))
        mkdir(mountdir.c_str(),0777);
		
    int partitionIndex = 1;
    for (; i<6; i++) {
        //printf("Try to mount %s of %s\n", mediakeys[mediachosenIndex][i],mediakeys[mediachosenIndex][1]);
        if (mediakeys[mediachosenIndex][i]!=NULL) {
            sprintf(mount, "mount %s %s >/dev/null 2>&1", mediakeys[mediachosenIndex][i],mountdir.c_str());

            if (0 != system(mount)) {
                //fprintf(stderr, "Failed mounting removable media!\n");
                //fprintf(stderr, "Try Partitionon %s of Selected USB Media Failed!\n", mediakeys[mediachosenIndex][i]);
                fprintf(stderr, "Try Partition %d of Selected USB Media Failed!\n", partitionIndex);
                ++partitionIndex;
            } else {
                dstPath = mountdir;
                found = 1;
                break;
            }
        }
    }

    if (!found) {
        sprintf(mount, "mount %s %s >/dev/null 2>&1", dev.c_str(), mountdir.c_str());
        if (0 != system(mount)) {
            fprintf(stderr, "Try Selected USB Media %s Mounted Failed!\n", dev.c_str());
        } else {
            fprintf(stderr, "Try Selected USB Media %s Mounted Successfully\n", dev.c_str());
            dstPath = mountdir;
            found = 1;
        }
    }

    if (found) {
        return 0;
    } else {
        return 1;
    }
#else
	return 0;
#endif
}

int TDsaCli::SubCopyUnmountMedia(std::string dstPath) {
    /*
       if(0 == strcmp(mnt, "/mnt/key")) {
          char umount[256];

          sprintf(umount, "umount %s", dev);
          system(umount);
       }
    */
    char umount[256];
    sprintf(umount, "umount %s", dstPath.c_str());
    system(umount);
    return 1;
}
void TDsaCli::SubCopyResult() {
#ifndef FDR_OS_WINDOWS
    std::string dev ;
    std::string devicename;
    std::string dstPath;
    std::string results;
    //int oem = SubCopyCheckOEM();
    int outputfilenum=0;
    int determineResult = SubCopyDetermineMedia();
    if (determineResult==1) {
        std::cout << "No Removable Media Is Found "<< std::endl;
        return;
    }
    if (determineResult==2) {
        std::cout <<"Copy Cancelled By User"<< std::endl;
        return;
    }
    if (mediachosenIndex!=-1) {
        //dev = (char *) malloc(strlen(mediapartitions[mediachosenIndex][0]));
        //strcpy(dev, mediapartitions[mediachosenIndex][0]);
        //dev = mediakeys[mediachosenIndex][0];
        dev =mediakeys[mediachosenIndex][1];
        devicename = mediakeys[mediachosenIndex][0];
    }

    if (dev.length() == 0) {
        std::cout << "Device not chosen." << std::endl;
        return;
    }

    if (0 != SubCopyMountMedia(dev, dstPath)) {
        return;
    }

    //printf("Copying to %s:%s\n", dev, dstPath);
    std::cout << "Copying to " << devicename << ": " << dstPath << std::endl;
    // Copy the text report
    if (findTextOutput(results)) {
        if (!fOEM) {
            //printf("Copying %s\n", results);
            std::cout << "Copying " << results << std::endl;
        } else {
            //printf("Copying TEXT Results\n");
            std::cout << "Copying TEXT Results" << std::endl;

        }
        SubCopyCopyFile(results, dstPath);
    } else
        outputfilenum+=1;

    // Copy the XML output
    if (findXmlOutput(results)) {
        if (!fOEM) {
            //printf("Copying %s\n", results);
            std::cout << "Copying " << results << std::endl;
        } else {
            //printf("Copying XML Results\n");
            std::cout << "Copying XML Results" << std::endl;
        }
        SubCopyCopyFile(results, dstPath);
    } else
        outputfilenum+=1;

    // Copy the html directory
    if (findHtmlOutput(results)) {
        char *htmlDirName = NULL;
        char dstDir[512];

        htmlDirName = strrchr((char*)results.c_str(), mediaFILE_SEPARATOR);
        sprintf(dstDir, "%s%s", dstPath.c_str(), htmlDirName);

        // Construct the name of the destination html directory
        strcat(dstDir, htmlDirName);

        if (!fOEM) {
            //printf("Copying %s\n", results);
            std::cout << "Copying " << results << std::endl;
        } else {
            //printf("Copying HTML Results\n");
            std::cout << "Copying HTML Results" << std::endl;
        }
        SubCopyCopyTree(results, dstPath);
    } else
        outputfilenum+=1;

    if (outputfilenum==3) {
        printf("Warning: nothing was collected. Please collect information before copy.\n");
        outputfilenum=0;
    }

    SubCopyUnmountMedia(dstPath);
#endif
}



void TDsaCli::RunInteractive() {
    interactive=true;
    for (;;) {
        std::string input = "";
        int selection = 0;
        int updatesupport=0;
        int updateselection=0;
        std::string className;
        std::string pageName;
        std::cout<<Interusage();

        selection = getSelection(fSol);
        updatesupport=helper->HelperUpdateIsSupport();

        if (selection >0 && selection < 10 || selection == 99 || selection == 98 || selection == 97) {
            switch (selection) {
            case 1://goes to datacollection submenu
                SubDataCollection();
                break;
            case 2://goes to diagnostic submenu
                SubDiagnostic();
                break;
            case 3://goes to copy information data subroutine
                SubCopyResult();
                break;
            case 4://transfer or quit to previous menu
                if (!fOEM) {
                    do {
                        input.clear();
                        std::cout<<"Customize FTP to transfer\?(y/n): ";
                        getline(cin, input);
                        if (fSol) {
                            if (input.empty()) {
                                std::getline(cin,input);
                            }
                        }

                    } while (input.empty());
                    if (input == "y"||input == "Y") {
                        TransferToUserFTP();
                        break;
                    } else if (input == "n"||input == "N") {
                        TransferToIBM();
                    } else
                        std::cout << "Invalid Option" << std::endl;
                } else {
                    return;//exit(0);
                }
                break;
            case 5:
                if (!fOEM) {
                    return;
                } else
                    std::cout<<"Invalid Option"<<std::endl<<std::endl;
                break;
            case 6: { //
                std::cout<<"Invalid Option"<<std::endl<<std::endl;
                /******** This part quit to previous menu if nonOEM case,supports update subfunction in cli *********/
                /*
                if (!fOEM){
                if  (updatesupport==0)
                exit(0);
                else
                std::cout<<"Invalid Option"<<std::endl<<std::endl;
                }
                else
                {
                std::cout<<"Invalid Option"<<std::endl<<std::endl;
                }
                */
            }
            break;
            case 97://enum html page
                std::cout<<"Enter Page name: ";
                std::cin>>pageName;
                std::cout<<helper->GetHTMLPage(pageName)<<std::endl;;
                break;
            case 98://enuminstances iBMC
                std::cout<<"iBMC Instances"<<std::endl;
                helper->DSAeiHttp();
                break;
            case 99://enuminstances
                std::cout<<"Enter Class name: ";
                std::cin>>className;
                DSAei(className);
                break;
            default://quit of invalid selection
                std::cout<<"Invalid Option"<<std::endl<<std::endl;
                break;
            }
        } else {
            std::cout<<"Invalid Option"<<std::endl<<std::endl;
        }
        input.clear();
        selection=0;
        updatesupport=0;
        updateselection=0;
    }
}
#if 0
void TDsaCli::RunInteractive() {
    //std::vector<std::map<std::string, std::string> > theVector;
    interactive=true;
    for (;;) {
        std::string input = "";
        int selection = 0;
        std::string className;
        std::string pageName;
        std::cout<<Interusage();
        do {
            std::stringstream mainInput;
            std::cin.clear();
            selection = 0;
            input.clear();
            std::cout << "Enter Number: ";
            std::getline(cin,input);
            if (fSol) {
                if (input.empty()) {
                    std::getline(cin,input);
                }
            }
            mainInput << input;
            mainInput >> selection;
        } while (input.empty());
        if ((selection >0 && selection < 10) || (selection == 99) || (selection == 98) || (selection == 97)) {
            switch (selection) {
            case 1://collect
                CollectData();
                break;
            case 2://view collect results
                View();
                break;
            case 3://exectest
                do {
                    std::string tapeEleName;
                    std::string tapeRWLBA;
                    std::string tapeRWBSP;
                    int testNumber = 0;
                    helper->GetTestVector()->clear();
                    helper->ListTests(helper->ParseTests(EnumerateDiagTests(dummy)));
                    int testSize = helper->GetTestVector()->size();

                    //workaround to limit bcom to 1 test
                    //fill a vector with the index's that are bcom tests, so we can check user selection later
                    bool bcomSelected = false;
                    std::vector<int > bcomVector;
                    std::vector<int > validTestsVector;
                    std::vector<std::vector<std::string> > bcomTempVector = *helper->GetTestVector();
                    for (int j=0; j< bcomTempVector.size(); j++) {
                        //if(bcomTempVector[j].begin()[0]=="TestControlRegisters" || bcomTempVector[j].begin()[0]=="TestEEPROM" || bcomTempVector[j].begin()[0]=="TestInternalMemory" || bcomTempVector[j].begin()[0]=="TestInterrupt" || bcomTempVector[j].begin()[0]=="TestLEDs" || bcomTempVector[j].begin()[0]=="TestLoopbackAtMACLayer" || bcomTempVector[j].begin()[0]=="TestLoopbackAtPhysicalLayer" || bcomTempVector[j].begin()[0]=="TestMIIRegisters"){
                        if (bcomTempVector[j].begin()[0]=="BMC I2C Test") {
                            bcomVector.push_back(j);
                        } else {
                            validTestsVector.push_back(j);
                        }
                    }//end bcom workaround to limit bcom to 1 test
                    int vectorHalf = testSize/2;
                    if ((int)testSize<=vectorHalf*2) {
                        int maxLine=50;
                        for (int k=0; k<maxLine; k++) {
                            std::cout<<" ";
                        }
                    }
                    if (testSize == 0)
                        std::cout<<"No available Tests for this machine"<<std::endl;
                    else
                        std::cout<<testSize+1<<" Run All Tests"<<std::endl;
                    std::cout<<"--------------------------------------------------------------------------------------------------\n";
                    do {
                        input.clear();
                        std::cout<<"Enter Number (type x to exit): ";
                        getline(cin, input);
                        if (fSol) {
                            if (input.empty()) {
                                std::getline(cin,input);
                            }
                        }
                    } while (input.empty());
                    std::stringstream testInput;
                    testInput << input;
                    testInput >> testNumber;
                    if ((!input.empty()) && (input != "x") && (input != "X")) {
                        if (testNumber > testSize+1 || (testNumber <=0) || !std::cin) {
                            std::cout<<"Invalid Test\n";
                        } else {
                            if (((*helper->GetTestVector())[testNumber-1]).begin()[0].find("Tape Drive") != std::string::npos) {
                                tapeEleName = ((*helper->GetTestVector())[testNumber-1]).begin()[2];
                            }

                            if (((*helper->GetTestVector())[testNumber-1]).begin()[0] == "Tape Drive: RW Self Test") {
                                int LBLen = 1;
                                int startpoint;
                                std::stringstream ssMaxDisp;
                                int iMax = 2097152;// 2TB = 2^21 MB
                                int iMax_1 = 2097151;// 2TB - 1

                                FILE *fd;
                                char line[80];

                                fd = fopen("tapeCap.tmp", "r");
                                if (fd != NULL) {
                                    if (fgets(line,sizeof(line), fd) != NULL) {
                                        std::string settingData(line);
                                        std::string devId = ((*helper->GetTestVector())[testNumber-1]).begin()[1];
                                        int devSPos = settingData.find(devId);
                                        if (devSPos != std::string::npos) {
                                            devSPos = settingData.find(" : ", devSPos);
                                            devSPos += 3;
                                            int devEPos = settingData.find("|", devSPos);
                                            if (devEPos == std::string::npos) {
                                                devEPos = settingData.size();
                                            }
                                            settingData = settingData.substr(devSPos, devEPos - devSPos);
                                            std::stringstream ssVal;
                                            ssVal << settingData;
                                            ssVal >> LBLen;
                                        }
                                    }
                                    fclose(fd);
                                }
                                system("rm -fr tapeCap.tmp");

                                ssMaxDisp.str("");
                                if (LBLen == 0) {
                                    std::cout<<"\nNotes: can not get the tape capability. Please ensure tape range is valid.\n";
                                    ssMaxDisp << "Max-1)MB: ";
                                } else {
                                    iMax = LBLen;
                                    iMax_1 = LBLen - 1;
                                    ssMaxDisp << iMax_1 << ")MB: ";
                                }

                                bool isValid = false;

                                // input Range of Tape startpoint
                                do {
                                    input.clear();
                                    std::cout<<"Range of Tape from (0 - "<<ssMaxDisp.str();
                                    getline(cin, input);
                                    if (fSol) {
                                        if (input.empty()) {
                                            std::getline(cin,input);
                                        }
                                    }

                                    int iInput = 0;
                                    std::stringstream ssCheck;
                                    ssCheck << input;
                                    ssCheck >> iInput;
                                    if (iInput >= 0 && iInput <= iMax_1) {
                                        isValid = true;
                                        startpoint = iInput;
                                        // match to logical block address
                                        iInput *= 2048; // LBA = iInmput * 2^20 / 512
                                        std::stringstream ssUI;
                                        ssUI << iInput;
                                        ssUI >> tapeRWLBA;
                                    } else {
                                        std::cout<<"Invalid Number! Please input again\n";
                                    }
                                } while (!isValid);

                                ssMaxDisp.str("");
                                ssMaxDisp << startpoint;
                                if (LBLen == 0) {
                                    ssMaxDisp << " - Max)MB: ";
                                } else {
                                    ssMaxDisp << " - "<< iMax << ")MB: ";
                                }

                                isValid = false;
                                // input Range of Tape endpoint
                                do {
                                    input.clear();
                                    std::cout<<"Range of Tape to (" << ssMaxDisp.str();
                                    getline(cin, input);
                                    if (fSol) {
                                        if (input.empty()) {
                                            std::getline(cin,input);
                                        }
                                    }

                                    int iInput = 0;
                                    std::stringstream ssCheck;
                                    ssCheck << input;
                                    ssCheck >> iInput;
                                    if (iInput >= startpoint && iInput <= iMax) {
                                        isValid = true;
                                        int BSP = (iInput - startpoint) * 2048 + 1;
                                        std::stringstream ssUI;
                                        ssUI << BSP;
                                        ssUI >> tapeRWBSP;
                                    } else {
                                        std::cout<<"Invalid Number! Please input again\n";
                                    }
                                } while (!isValid);
                            }

                            do {
                                input.clear();
                                std::cout<<"Number of Loops (1-25): ";
                                getline(cin, input);
                                if (fSol) {
                                    if (input.empty()) {
                                        std::getline(cin,input);
                                    }
                                }
                            } while (input.empty());

                            //workaround for bcom
                            //if a single test was selected, check it against array index of bcom
                            if (testNumber!=testSize+1) {
                                for (int j=0; j< bcomVector.size(); j++) {
                                    if ((bcomVector[j]+1)==(int)testNumber) {
                                        bcomSelected=true;
                                    }
                                }
                            }
                            if (bcomSelected) {
                                std::stringstream numLoops;
                                int loopCount=0;
                                numLoops << input;
                                numLoops >> loopCount;
                                if (loopCount > 0 && loopCount <=25) {
                                    if (loopCount>1) {
                                        std::cout<<"Looping is not supported for the BMC I2C Test"<<std::endl;
                                    }
                                    std::cout<<(*helper->GetTestVector())[testNumber-1].begin()[0]<<std::endl;
                                    std::cout<<"Test 1 of 1"<<std::endl;
                                    std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2],dummy)<<std::endl<<std::endl;
                                    std::cout<< "Press Enter To Continue...";
                                    getchar();
                                } else {
                                    std::cout<<"Invalid Number\n";
                                }
                                input.clear();
                                testNumber = 0;
                            } else {//else for bcom workaround
                                std::stringstream numLoops;
                                int loopCount=0;
                                numLoops << input;
                                numLoops >> loopCount;
                                if (loopCount > 0 && loopCount <=25) {
                                    if (testNumber!=testSize+1) {
                                        if ((((*helper->GetTestVector())[testNumber-1]).begin()[0]=="DiskDriveDiagnosticTest")&& (loopCount > 10)) {
                                            std::cout<<"Maximum ten loops are supported for this Test"<<std::endl;
                                            loopCount = 10;
                                            for (int i=1; i<=loopCount; i++) {
                                                std::cout<<(*helper->GetTestVector())[testNumber-1].begin()[0]<<std::endl;
                                                std::cout<<"Test "<<i<<" of "<<loopCount<<std::endl;
                                                std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2],dummy)<<std::endl<<std::endl;
                                            }
                                        } else {
                                            for (int i=1; i<=loopCount; i++) {
                                                std::cout<<(*helper->GetTestVector())[testNumber-1].begin()[0]<<std::endl;
                                                std::cout<<"Test "<<i<<" of "<<loopCount<<std::endl;
                                                if (!tapeEleName.empty() || (!tapeRWLBA.empty() && !tapeRWBSP.empty())) {
                                                    std::string strParam = tapeEleName + " : Tape RW Test|" + tapeRWLBA + "|" + tapeRWBSP;
                                                    std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2], strParam)<<std::endl<<std::endl;
                                                } else {
                                                    std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2],dummy)<<std::endl<<std::endl;
                                                }
                                            }
                                        }
                                    } else {
                                        std::cout<<"Looping is not supported for the BMC I2C Test"<<std::endl;
                                        //do all of broadcom once, then move on to loop the others
                                        for (unsigned int i=0; i<bcomVector.size(); i++) {
                                            std::cout<<(*helper->GetTestVector())[bcomVector[i]].begin()[0]<<std::endl;
                                            std::cout<<"Test 1 of 1"<<std::endl;
                                            std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[bcomVector[i]]).begin()[0]+","+((*helper->GetTestVector())[bcomVector[i]]).begin()[1]+","+((*helper->GetTestVector())[bcomVector[i]]).begin()[2],dummy)<<std::endl<<std::endl;
                                        }
                                        for (int i=0; i<loopCount; i++) {
                                            //for(int allLoop = 0; allLoop<testSize; allLoop++){
                                            for (int allLoop = 0; allLoop<validTestsVector.size(); allLoop++) {
                                                std::cout<<(*helper->GetTestVector())[validTestsVector[allLoop]].begin()[0]<<std::endl;
                                                std::cout<<"Test "<<i+1<<" of "<<loopCount<<std::endl;
                                                std::cout<<ExecuteDiagTest(((*helper->GetTestVector())[validTestsVector[allLoop]]).begin()[0]+","+((*helper->GetTestVector())[validTestsVector[allLoop]]).begin()[1]+","+((*helper->GetTestVector())[validTestsVector[allLoop]]).begin()[2],dummy)<<std::endl<<std::endl;
                                            }
                                        }
                                    }
                                    std::string resultInput = "";
                                    std::cout<< "Press Enter To Continue...";
                                    getchar();
                                } else {
                                    std::cout<<"Invalid Number\n";
                                }
                                input.clear();
                                testNumber = 0;
                            }//end else for bcom workaround
                        }
                    }
                } while ((input != "x") && (input != "X"));
                std::cout << std::endl;
                break;
            case 4://getextendedresult
                do {
                    int testNumber = 0;
                    helper->GetTestVector()->clear();
                    helper->ListTests(helper->ParseTests(EnumerateDiagTests(dummy)));
                    std::cout << std::endl;
                    std::cout<<"--------------------------------------------------------------------------------------------------\n";
                    do {
                        input.clear();
                        std::cout<<"Enter Number (type x to exit): ";
                        getline(cin, input);
                        if (fSol) {
                            if (input.empty()) {
                                std::getline(cin,input);
                            }
                        }

                    } while (input.empty());
                    std::stringstream resultInput;
                    resultInput << input;
                    resultInput >> testNumber;
                    if ((!input.empty()) && (input != "x") && (input != "X")) {
                        if ((int)testNumber > helper->GetTestVector()->size() || (testNumber <=0) || !std::cin) {
                            std::cout<<"Invalid Test\n";
                        } else {
                            std::cout<<std::endl;
                            std::cout<<GetExtendedResults(((*helper->GetTestVector())[testNumber-1]).begin()[0]+","+((*helper->GetTestVector())[testNumber-1]).begin()[1]+","+((*helper->GetTestVector())[testNumber-1]).begin()[2])<<std::endl<<std::endl;
                            std::cout<< "Press Enter To Continue...";
                            getchar();
                        }
                    }
                } while ((input != "x") && (input != "X"));
                break;
            case 5://transfer
                if (!fOEM) {
#ifndef PREBOOT
                    do {
                        input.clear();
                        std::cout<<"Customize FTP to Transfer\?\?(Yy/Nn): ";
                        getline(cin, input);
                        if (fSol) {
                            if (input.empty()) {
                                std::getline(cin,input);
                            }
                        }

                    } while (input.empty());
                    if (input == "y"||input == "Y") {
                        TransferToUserFTP();
                        break;
                    } else if (input == "n"||input == "N") {
                        TransferToIBM();
                    } else
                        std::cout << "Invalid Option" << std::endl;
#else
                    TransferToIBM();
#endif
                } else {
                    return;//exit(0);
                }
                break;
            case 6://copy
                dsacliMediaCopy();
                break;
            case 7://quit
                if (!fOEM) {
                    return;//exit(0);
                }
                break;
            case 97://reset iBMC
                std::cout<<"Enter Page name: ";
                std::cin>>pageName;
                helper->GetHTMLPage(pageName);
                break;
            case 98://enuminstances iBMC
                std::cout<<"iBMC Instances"<<std::endl;
                helper->DSAeiHttp();
                break;
            case 99://enuminstances
                std::cout<<"Enter Class name: ";
                std::cin>>className;
                DSAei(className);
                break;

            default://quit
                break;
            }
        } else {
            std::cout<<"Invalid Option"<<std::endl<<std::endl;
        }
        input.clear();
        selection = 0;
    }
}
#endif
void TDsaCli::View() {
#if !defined(FDR_OS_WINDOWS)
    std::string textOutput;
    if (!findTextOutput(textOutput)) {
        fprintf(stderr, "Failed locating text report!\n");
        fprintf(stderr, "You must first run a collection to view results\n");
        return;
    }
    if (0 != launchTextEditor(textOutput)) {
        fprintf(stderr, "Failed launching text editor!\n");
        return;
    }
#else
    std::cout<<"Only Available in Linux\n\n";
#endif
}

int TDsaCli::findTextOutput(std::string &buf) {
    /*
    #if !defined(FDR_OS_WINDOWS)
       if(!findXmlOutput(buf)) {
          return 0;
       }
       buf+".txt";
       return fileExists(buf);
    #else
       return 0;
    #endif
    */
    std::string path;
#if !defined(FDR_OS_WINDOWS)
    if (!fOEM) {
        char* outputDir = "/var/log/IBM_Support/";
        path = "/var/log/IBM_Support/";
        if (!dirExists(path))
            return 0;
        std::string resultsFile = findLatestFile(outputDir, ".txt");
        if (resultsFile.length() > 0) {
            buf = "/var/log/IBM_Support/" + resultsFile;
            return 1;
        }
    } else {
        char* outputDir = "/var/log/OEM_Support/";
        path = "/var/log/OEM_Support/";
        if (!dirExists(path))
            return 0;
        std::string resultsFile = findLatestFile(outputDir, ".txt");
        if (resultsFile.length() > 0) {
            buf = "/var/log/OEM_Support/" + resultsFile;
            return 1;
        }
    }
    return 0;
#else
    return 0;
#endif
}

int TDsaCli::findHtmlOutput(std::string &buf) {
#if !defined(FDR_OS_WINDOWS)
    int len;
    if (!findTextOutput(buf)) {
        return 0;
    }
    std::string::size_type pos = buf.find(".txt");
    buf = buf.substr(0,pos);
    return dirExists(buf);
#else
    return 0;
#endif
}
int TDsaCli::findXmlOutput(std::string &buf) {
    std::string path;
#if !defined(FDR_OS_WINDOWS)
    if (!fOEM) {
        char* outputDir = "/var/log/IBM_Support/";
        path = "/var/log/IBM_Support/";
        if (!dirExists(path))
            return 0;
        std::string resultsFile = findLatestFile(outputDir, ".xml.gz");
        if (resultsFile.length() > 0) {
            buf = "/var/log/IBM_Support/" + resultsFile;
            return 1;
        }
    } else {
        char* outputDir = "/var/log/OEM_Support/";
        path = "/var/log/OEM_Support/";
        if (!dirExists(path))
            return 0;
        std::string resultsFile = findLatestFile(outputDir, ".xml.gz");
        if (resultsFile.length() > 0) {
            buf = "/var/log/OEM_Support/" + resultsFile;
            return 1;
        }
    }
    return 0;
#else
    return 0;
#endif
}

std::string TDsaCli::findLatestFile(char *parentPath, char *ext) {
#if !defined(FDR_OS_WINDOWS)
    DIR *dir;
    struct dirent *entry;
    struct stat entry_stat;
    time_t latestTime = 0;
    char latestFilename[128];
    char path[512];
    char *filename;
    int parentPathLen;
    parentPathLen = strlen(parentPath);
    memcpy(path, parentPath, parentPathLen);
    filename = path + parentPathLen;
    dir = opendir(parentPath);
    bool fileFound = false;
    while ((entry = readdir(dir))) {
        int namelen = strlen(entry->d_name);
        // check extension
        if (0 != strcmp(ext, entry->d_name + namelen - strlen(ext))) {
            continue;
        }
        // construct full path and stat
        strcpy(filename, entry->d_name);
        if (stat(path, &entry_stat) == -1) {
            continue;
        }
        if (S_ISDIR(entry_stat.st_mode)) {
            continue;
        }

        // check if this is the latest one
        if (fileFound == false) {
            latestTime = entry_stat.st_mtime;
            strcpy(latestFilename, entry->d_name);
            fileFound = true;
        } else if (latestTime < entry_stat.st_mtime) {
            strcpy(latestFilename, entry->d_name);
            latestTime = entry_stat.st_mtime;
        }
    }

    if (fileFound == false) {
        //std::cout<<"null "<<std::endl;
        return "";
    } else {
        std::string ret = latestFilename;
        return ret;
    }
#else
    return "";
#endif
}

int TDsaCli::launchTextEditor(std::string args) {
#if !defined(FDR_OS_WINDOWS)
    std::string theCommand = "vi -R " + args;
    return system(theCommand.c_str());
#else
    return 0;
#endif
}

int TDsaCli::fileExists(std::string name) {
#if !defined(FDR_OS_WINDOWS)
    struct stat _stat;
    int rc = stat(name.c_str(), &_stat);
    if (rc < 0) {
        return 0;
    }
    return !S_ISDIR(_stat.st_mode);
#else
    return 0;
#endif
}

int TDsaCli::dirExists(std::string dirname) {
#ifndef FDR_OS_WINDOWS
    struct stat _stat;

    int rc = stat(dirname.c_str(), &_stat);
    if (rc < 0) {
        return 0;
    }

    return S_ISDIR(_stat.st_mode);
#else
	return 0;
#endif
}
void TDsaCli::InitialThread(){
#ifndef FDR_OS_WINDOWS
	  	pthread_t thread;
                pthread_attr_t attr;
                pthread_attr_init(&attr);
		int status = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
                if (status != 0) {
                } else {
                }
                status = pthread_create(&thread, &attr, (*ExecuteInThread), this);
                if (status != 0) {
                } else {
                }
                printStatus();
	       threadFinished=0;
	       EnumeratedTest=1;
#endif
}
void* TDsaCli::ExecuteInThread(void* job) {
	std::string newew=marshall->EnumerateDiagTests(dummy);
    threadFinished = 1;
    return NULL;
}
void TDsaCli::printStatus() {
    std::cout << "System is scanning possible diagnostics, please wait!";
	while (threadFinished!=1) {
		helper->CaptureConsole(".");
		#if !defined (FDR_OS_WINDOWS)
            sleep(1);
#else
            Sleep(1000);
#endif
		}
}
