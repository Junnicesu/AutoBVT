/*************************************************************************
*
* THTMLNAMESPACECONSUMER.H - NSC wrapper for HTML writer.
*
* Copyright (C) 2006 IBM Corporation
*
*************************************************************************/

#ifndef _THTMLNAMESPACECONSUMER_H
#define _THTMLNAMESPACECONSUMER_H

#include <string>

#include "INamespaceConsumer.h"


namespace NIBMDSA20 {


class THtmlNamespaceConsumer : public INamespaceConsumer {
public:
   virtual ~THtmlNamespaceConsumer() {}

   const std::string &GetName(TCIMContext context = TCIMContext()) const;

   // Namespaces.
   void ConsumeNamespace(boost::shared_ptr<ICIMNamespace> cimNamespace,
                         TCIMContext context = TCIMContext());

   //std::string GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> pluginNamespace, boost::shared_ptr<ICIMNamespace> cmpiNamespace, const IConsumeProvidersCallback &callback, TCIMContext context = TCIMContext());
   std::string GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> unionNamespace, const IConsumeInstancesCallback &callback, uint32_t dataNeeded, TCIMContext context = TCIMContext());

public:

   static void Initialize(std::string homePath);
   static boost::shared_ptr<THtmlNamespaceConsumer> GetInstance();

private:

   THtmlNamespaceConsumer(std::string homePath);

   std::string fHomePath;

   static boost::shared_ptr<THtmlNamespaceConsumer> fgInstance;
};


};

#endif
