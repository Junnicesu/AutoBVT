/*************************************************************************
*
* THTMLNAMESPACECONSUMER.CPP - NSC wrapper for HTML writer.
*
* Copyright (C) 2006 IBM Corporation
*
*************************************************************************/

#include "TDSAException.h"
#include "TOSSpecific.h"
#include "linkage.h"

#include "TReport.h"
#include "TReport_vmwesxi.h"
#include "TWriter_vmwesxi.h"

#include "THtmlNamespaceConsumer.h"
#include "THtmlWriter.h"
#include "THtmlWriter_vmwesxi.h"

namespace NIBMDSA20 {


boost::shared_ptr<THtmlNamespaceConsumer> THtmlNamespaceConsumer::fgInstance = boost::shared_ptr<THtmlNamespaceConsumer>();


void THtmlNamespaceConsumer::Initialize(std::string homePath) {
   fgInstance = boost::shared_ptr<THtmlNamespaceConsumer>(new THtmlNamespaceConsumer(homePath));
}


boost::shared_ptr<THtmlNamespaceConsumer> THtmlNamespaceConsumer::GetInstance() {
   return fgInstance;
}


THtmlNamespaceConsumer::THtmlNamespaceConsumer(std::string homePath)
: fHomePath(homePath) {
}


const std::string &THtmlNamespaceConsumer::GetName(TCIMContext context) const {
   static std::string name = "html";

   return name;
}


// Namespaces.
void THtmlNamespaceConsumer::ConsumeNamespace(boost::shared_ptr<ICIMNamespace> cimNamespace, TCIMContext context)
{
	TCIMContext::iterator iter = context.end();

	TReport report(boost::const_pointer_cast<ICIMNamespace>(cimNamespace), context, fHomePath);
	THtmlWriter writer;

	TReport_vmwesxi report_vmwesxi(boost::const_pointer_cast<ICIMNamespace>(cimNamespace), context, fHomePath);
	THtmlWriter_vmwesxi writer_vmwesxi;

	std::string szNSP = "";
	
	if ((iter = context.find("nsp")) != context.end())
	{
		szNSP = ((*iter).second).ToString();
	}

	if ("vmwesxi" == szNSP)
	{
		report_vmwesxi.Write(&writer_vmwesxi, context);
	}
	else
	{
		report.Write(&writer, context);
	}
}

//std::string THtmlNamespaceConsumer::GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> pluginNamespace, boost::shared_ptr<ICIMNamespace> cmpiNamespace, const IConsumeProvidersCallback &callback, TCIMContext context){
std::string THtmlNamespaceConsumer::GetData(boost::shared_ptr<ICIMNamespace> cimNamespace, boost::shared_ptr<ICIMNamespace> unionNamespace, const IConsumeInstancesCallback &callback, uint32_t dataNeeded, TCIMContext context){
	return "";
}


extern "C" {
// This function is called by TOSSpecific::LoadNSCLibrary
DLLEXPORT INamespaceConsumer *html_CreateINamespaceConsumer() {
   THtmlNamespaceConsumer::Initialize(TOSSpecific::GetDSARootPath());
   return THtmlNamespaceConsumer::GetInstance().get();
}
}


};
