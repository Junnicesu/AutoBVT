/*************************************************************************
*
* TCIMDATAHELPER.CPP - Command line client.
*
* Copyright (C) 2004-2007 IBM Corporation
*
*************************************************************************/

#include <sstream>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <utility>
#include <signal.h>
#include <string>
#include <vector>
#if FDR_COMPILER == msvc
// Disable these warnings on the MSVC compiler.
#pragma warning(push)
#pragma warning(disable: 4127 4511 4512)
#endif
#include "boost/lexical_cast.hpp"
#include "boost/scoped_ptr.hpp"
#if FDR_COMPILER == msvc
#pragma warning(pop)
#endif

#include "ICIMInstance.h"
#include "INamespaceProviderManager.h"
#include "ICIMNamespace.h"
#include "ICIMProperty.h"
#include "ICIMPropertyDecl.h"
#include "IProvider.h"
#include "INamespaceProvider.h"
#include "TRootObject.h"
#include "TDSAException.h"
#include "TOSSpecific.h"
#include "TPluginManagerNamespace.h"
#include "TCIMSchemaHelper.h"
#include "version.h"
#include "cimdatahelper.h"
#include "TCIMCopy.h"
#include "TNamespacePopulator.h"
#include "TNamespaceConsumerManager.h"
#include "TDeltaNamespace.h"
#include "TCMPINamespace.h"
#include "TIBMCNamespace.h"
#ifndef FDR_OS_WINDOWS
#include "TXHYPNamespace.h"
#endif
#include "TCimHTTPNamespace.h"
#include "pluginmgr.h"
#include "TXMLWriter.h"
#include "../diagsrunner/TDiagsRunner.h"
#include "zfstream.h"
#include "splibrary.h"
#include "sharedloader.h"


#if defined(FDR_OS_WINDOWS)
// Bring this in to be able to set the process priority.
#define _WIN32_WINNT 0x0501
#include "windows.h"
#else
#include <netdb.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <dirent.h>
#include <dlfcn.h>
#include <fcntl.h>
#endif

#if defined(FDR_OS_WINDOWS)
#include "minidumper.h"
MiniDumper dumper("DSA_Core");
#endif


using namespace NIBMDSA20;
using namespace std;

//BUGBUG For some reason can't link to TOSSpecific::kFileSeparator
#ifdef FDR_OS_WINDOWS
const std::string kFileSeparator("\\");
const std::string kPluginName_ux("ux");
const std::string kPluginName_system("system");
#else
const std::string kFileSeparator("/");
const std::string kPluginName_ux("libux");
const std::string kPluginName_system("libsystem");
#endif

// The default NSPs to use.
const std::string kOutputRepositoryNamespaceName("inmem");
//const std::string kOutputRepositoryNamespaceName("sqlite");
const std::string kProviderNamespaceName("plugin");
//const std::string kProviderNamespaceName("cmpi");
const std::string kProviderNamespaceRepositoryName("inmem");
const std::string kDeltaNamespaceName("delta");
const std::string kUnionNamespaceName("union");


ILogger *logger;
std::string execDir;
TCIMDataHelper *fgInstance;


//************************************Callback Method
class TAddInstanceToOutputRepositoryNamespace : public std::unary_function<boost::shared_ptr<ICIMInstance>, bool> {
public:
    TAddInstanceToOutputRepositoryNamespace(boost::shared_ptr<ICIMNamespace> outputRepositoryNamespace)
            : fOutputRepositoryNamespace(outputRepositoryNamespace) {
    }
    ~TAddInstanceToOutputRepositoryNamespace() {
    }

    bool operator()(boost::shared_ptr<ICIMInstance> instance) {
        try {
            TCIMCopy::CopyInstance(instance, fOutputRepositoryNamespace);
        } catch (TDSAException ex) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError,
                    "Failed copying instance: " + instance->BuildPath().GetPath() + ". reason = " + ex.what());
        }
        return true;
    }

private:
    boost::shared_ptr<ICIMNamespace> fOutputRepositoryNamespace;
};


class TProviderCollectionStatus {
public:
    TProviderCollectionStatus(TCIMDataHelper *client, boost::shared_ptr<IProvider> provider, bool forcedRun, bool displayName)
            : fClient(client)
            , fProvider(provider)
            , fClassesCollected(false)
            , fForcedRun(forcedRun)
            , fDisplayName(displayName) {
    }

    ~TProviderCollectionStatus() {
        if (fClassesCollected && !fForcedRun && fDisplayName) {
            fClient->CaptureConsole("\n");
        }
    }

    void HandleClassCollected() {
        if (!fClassesCollected && !fForcedRun && fDisplayName) {
            std::string modName = fProvider->GetModuleName();
            //std::string name = fProvider->GetName();
            std::string desc = fProvider->GetDescription();
            fClient->CaptureConsole("   " + modName + ": " + desc + " ");
            fClient->SetDisplayedProviders(modName);
        }
        fClassesCollected = true;
    }

private:
    TCIMDataHelper *fClient;
    boost::shared_ptr<IProvider> fProvider;
    bool fClassesCollected;
    bool fForcedRun;
    bool fDisplayName;
};


class TCollectClassInstances : public std::unary_function<boost::shared_ptr<ICIMClass>, bool> {
public:
    TCollectClassInstances(TProviderCollectionStatus &collectionStatus,
                           boost::shared_ptr<ICIMNamespace> outputRepositoryNamespace,
                           bool getAssociations,
                           TCIMContext context)
            : fCollectionStatus(collectionStatus)
            , fOutputRepositoryNamespace(outputRepositoryNamespace)
            , fGetAssociations(getAssociations)
            , fContext(context) {
    }
    ~TCollectClassInstances() {
    }

    bool operator()(boost::shared_ptr<ICIMClass> cimClass) {
        if (cimClass->IsAssociation() == fGetAssociations) {
            fCollectionStatus.HandleClassCollected();
            cimClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(fOutputRepositoryNamespace), false, fContext);
        }
        return true;
    }

private:
    TProviderCollectionStatus &fCollectionStatus;
    boost::shared_ptr<ICIMNamespace> fOutputRepositoryNamespace;
    bool fGetAssociations;
    TCIMContext fContext;
};

class TCollectDataFromProvider : public std::unary_function<boost::shared_ptr<IProvider>, bool> {
public:
    TCollectDataFromProvider(boost::shared_ptr<ICIMNamespace> outputRepositoryNamespace,
                             TCIMDataHelper *client, bool getAssociations, std::string dumpXMLFilename)
            : fOutputRepositoryNamespace(outputRepositoryNamespace)
            , fClient(client)
            , fGetAssociations(getAssociations)
            , fDumpXMLFilename(dumpXMLFilename) {
    }
    ~TCollectDataFromProvider() {
    }

    bool operator()(boost::shared_ptr<IProvider> iprovider) {
        bool collectorFound = (std::find(fClient->fCollectors.begin(), fClient->fCollectors.end(), iprovider->GetName()) != fClient->fCollectors.end());
        bool forcedRun = false; // this should only happen with system

        //Since the cmpi providers have a provider object for every classname, check if we have already displayed the name, and only enumerate instances.
        std::string modName = iprovider->GetModuleName();
        bool displayName = (std::find(fClient->finishedProviders.begin(), fClient->finishedProviders.end(), modName) == fClient->finishedProviders.end());
        std::string name = iprovider->GetName();
        std::string desc = iprovider->GetDescription();

        if (collectorFound != fClient->fIsPluginIncluded) {
            // don't run this plugin
            fClient->CaptureConsole("     Disabled - " + name + ": " + desc + "\n");

            if (name != kPluginName_system) {
                return true;
            } else {
                forcedRun = true;
            }
        }

        TCIMContext context;

        if (name == kPluginName_ux) {
            if (fClient->fUpdateExpressPath.empty()) {
                // We weren't asked to execute UX... go on to the next provider
                return true;
            } else {
                // Pass the UX path to the provider via the TCIMContext
                context.insert(make_pair(std::string("uxPath"), TCIMValue(fClient->fUpdateExpressPath)));
            }
        }

        // collect the instances
        try {
            TProviderCollectionStatus collectionStatus(fClient, iprovider, forcedRun, displayName);
            iprovider->EnumerateClassesProvided(TCollectClassInstances(collectionStatus,
                                                fOutputRepositoryNamespace,
                                                fGetAssociations,
                                                context),
                                                context);
        } catch (std::exception &ex) {
            std::stringstream x;
            x << "Plugin " << name << " threw exception " << ex.what();
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError, x.str());

            // Continue on to the next plugin.
        }

        if (fClient->fWriteXMLAfterEachPlugin) {
            fClient->AddDSALogToContainer(fOutputRepositoryNamespace);
            fClient->WriteXMLOutput(fOutputRepositoryNamespace, fDumpXMLFilename);
        }
        return true;
    }

private:
    boost::shared_ptr<ICIMNamespace> fOutputRepositoryNamespace;
    TCIMDataHelper *fClient;
    bool fGetAssociations;
    std::string fDumpXMLFilename;
};
//************************************End Callback Method

TCIMDataHelper::TCIMDataHelper()
        : fIsPluginIncluded(false)
        , fCreateDir(false)
        , fBatchMode(false)
        , fXMLEnable(true)
        , fTextEnable(false)
        , fHTMLEnable(false)
        , fWebsite(false)
        , fHelpRequested(false)
        , fWriteXMLAfterEachPlugin(false)
        , fDiagsEnable(false)
        , fHTMLRepositary(false)
        , fpropOverwrite(true)
        , fOEM(false)
        , fHTTP(false) {
    SetupLogging();
    SetupProviderConfig();
    LoadProvidersNSPs();
    LoadCDMProvidersNSPs();
    LoadHTTPProvidersNSP();
#ifndef FDR_OS_WINDOWS
    if (IsOEM()) {
        fOEM=true;
    }
#endif
    //Get DSA Version
    boost::shared_ptr<NIBMDSA20::ICIMClass> pClass;
    std::vector<boost::shared_ptr<NIBMDSA20::ICIMInstance> > instancesVector;
    try {
        pClass = fUnionNamespace->GetClass("IBMSG_DSAProduct");
        pClass->EnumerateInstances(NIBMDSA20::TAddInstancesToVectorCallback(instancesVector));

        cDSAVersion = instancesVector[0]->GetProperty("Version")->ToString();
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"TCIMDataHelper::TCIMDataHelper, cDSAVersion=" + cDSAVersion);
    } catch (TDSAException &ex) {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"TCIMDataHelper::TCIMDataHelper, get Current DSA version failed");
        return;
    }
    fIBMFtpAddress = "";
}
TCIMDataHelper::~TCIMDataHelper() {
	NIBMDSA20::SharedLoader::FreeInstance();
};

TCIMDataHelper* TCIMDataHelper::GetCIMDataHelper() {
    if (!fgInstance) {
        fgInstance = new TCIMDataHelper;
    }
    return fgInstance;
}

void TCIMDataHelper::FreeCIMDataHelper() {
    delete fgInstance;
}

void TCIMDataHelper::SetupProviderConfig(){
        std::string lsiConf;
        std::string lsiSettings;
        std::string workingDir = TOSSpecific::GetCurrentDir();
#if defined(FDR_OS_WINDOWS)
        lsiConf = workingDir + "\\lsi_mr.conf";
        lsiSettings = "DATA_DIR=" + workingDir + "\\lsi_mir" + "\nLIBRARY_DIR=" + workingDir + "\\lsi_mir\n";
#else
        lsiConf = "/tmp/lsi_mr.conf";
        lsiSettings = "DATA_DIR=" + workingDir + "/lsi_mir" + "\nLIBRARY_DIR=" + workingDir + "/lsi_mir\n";
#endif
    ofstream ofstr(lsiConf.c_str(), ios_base::trunc);
    ofstr << lsiSettings;
    ofstr.close();
#ifndef FDR_OS_WINDOWS
    std::string symboliclinkCall = "ln -sf " + lsiConf + " /lsi_mr.conf > /dev/null 2>&1";
    system(symboliclinkCall.c_str());
#endif
}

class TFindProvider {
public:
    TFindProvider(std::string name)
            : fName(name)
            , fExists(false) {
    }
    bool HandleProvider(boost::shared_ptr<IProvider> provider) {
        if (provider->GetName() == fName) {
            fExists = true;
            return false;
        } else {
            return true;
        }
    }

    std::string fName;
    bool fExists;
};


class TEnumerateSystemCreation {
public:
    TEnumerateSystemCreation()
            : fFirstInstance(boost::shared_ptr<ICIMInstance>()) {
    }
    bool HandleInstance(boost::shared_ptr<ICIMInstance> instance) {
        fFirstInstance = instance;
        return false;
    }

    boost::shared_ptr<ICIMInstance> fFirstInstance;
};


/* ***********************************************************************************************
 * Collect - callects the system information.
 *
 * Called by: DSAGlueImpl::CollectData
 *
 * Inputs: inOptions - string of options that effect the data collection.
 *                      -v       - create HTML ouput
 *                      -x       - Do not create compressed XML file
 *                      -dumpxml - Write the DSA .xml.gz file after each plugin
 *
 * ***********************************************************************************************
 */

void TCIMDataHelper::Collect(std::vector<std::string> inOptions) {
    fOutputBaseName.clear();
    outputRepositoryNamespace->ClearInstances();
    TCIMCopy::CopyClasses(fUnionNamespace, outputRepositoryNamespace, false);
    if (fHTTP) {
        TCIMCopy::CopyClasses(httpProviderNamespace, outputRepositoryNamespace, false);
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::Collect" );
    if (!fOEM) {
        system("rm -fr /var/log/IBM_Support/*");
        CaptureConsole(FDR_PRODUCTNAME " Version " FDR_VER_STRING "\n");
        CaptureConsole(FDR_LEGALCOPYRIGHT_STRING "\n");
    } else {
        system("rm -fr /var/log/OEM_Support/*");
        CaptureConsole("Dynamic System Analysis Version " FDR_VER_STRING "\n");
    }

    // Get the name of this module.
    char filename[250];

#if defined(FDR_OS_WINDOWS)
    int numchars = GetModuleFileName(NULL, filename, sizeof(filename));
    if (numchars == 0 || numchars == sizeof(filename)) {
        // error occurred
        CaptureConsole(static_cast<std::string>("ERROR: Collectall initalization failure") + "\n");
        //WaitForKeyAndExit(1);
    }
    // Search backwards for the final backslash.
    char *pathName = strrchr(filename, '\\');
    // Remove the actual name of the module and leave just the path name.
    *pathName = '\0';
    std::string pathToCollectall = filename;
#else
    std::string pathToCollectall = NIBMDSA20::TOSSpecific::GetDSARootPath();
    setenv("FDR_FILELOADER_CONFIG",pathToCollectall.c_str(),1);
#endif



#ifdef __linux__
    {
        // for 353020
        xenRunningType xentype = xenNotRun;
        xentype = TOSSpecific::GetRunningTypeOnXen();
        if (xentype == xenOnDom0) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevStatus, "DSA was run on xen dom0.");
        } else if (xentype == xenOnDomU) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevStatus, "DSA was run on xen domU.");
        }
    }
#endif

    // For portable installer we need to determine the directory from which the installer was launched. Relative paths
    // should be relative to that path.
    char *execDirEnv = getenv("IBM_PORTABLE_EXEC_DIR");
    execDir = execDirEnv ? execDirEnv : "";

    //enable text by default for embedded
    fTextEnable = true;
    //Parse the vector
    //Reset all options
    fHTMLEnable = false;
    fWriteXMLAfterEachPlugin = false;
    fXMLEnable = true;
    fBatchMode = false;
    //end for 432765
    for (uint32_t i=0; i<inOptions.size(); i++) {
        std::string checkOption = inOptions[i];
        std::transform(checkOption.begin(), checkOption.end(),checkOption.begin(), ::tolower);
        if (checkOption == "debug") {
            logger->SetLogThreshold(ILogger::EDSALogSeverity(4));
        } else if (checkOption == "v") {
            fHTMLEnable = true;
        } else if (checkOption == "dumpxml") {
            fWriteXMLAfterEachPlugin = true;
        } else if (checkOption == "x") {
            fXMLEnable = false;
        } else if (checkOption == "b") {
            fBatchMode = true;
        } else if (checkOption == "u") {
        } else if (inOptions[i] == "f") {
            putenv("FDR_RETRIEVE_FULL_H8_LOGS=1");
        } else if (checkOption == "r") {
        } else {
            CaptureConsole("\nUnknown Option, running with defaults.\n");
        }
    }
    fUpdateExpressPath = "_live_";
    if (fInputFile.empty() && !TOSSpecific::IsAdmin()) {
        CaptureConsole("ERROR: You must be logged in with Administrator privileges in order to run DSA.\n");
        //WaitForKeyAndExit(1);
    }

    // If the user didn't specify a target directory, then create the default
    // directory if necessary.
    if (fTargetDir.empty()) {
        // BUGBUG AA040704: This should be converted over to the BOOST filesystem library.
#if defined(FDR_OS_WINDOWS)
        fTargetDir = std::string(getenv("SYSTEMDRIVE")) + "\\IBM_Support";
#else
        if (!fOEM) {
            fTargetDir = "/var/log/IBM_Support";
        } else {
            fTargetDir = "/var/log/OEM_Support";
        }
#endif

        fCreateDir = true;
    }

    // Find out if the directory already exists.
    bool dirExists = false;
    try {
        dirExists = TOSSpecific::DirExists(fTargetDir);
        if (fHTMLRepositary) {
            dirExists = TOSSpecific::DirExists(fHTMLDir);
        }
    } catch (TDSAException &ex) {
        if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusFileSystemError) {
            if (fHTMLRepositary) {
                CaptureConsole("ERROR: Invalid directory '" + fHTMLDir + "' specified.\n");
            } else {
                CaptureConsole("ERROR: Invalid directory '" + fTargetDir + "' specified.\n");
            }
        } else {
            CaptureConsole(std::string("ERROR: DirExists returned exception code ") + ex.what() + "\n");
        }

        //WaitForKeyAndExit(1);
    }

    if (!dirExists) {
        // Create the directory if we were requested to.
        if (fCreateDir) {
            try {
                if (fHTMLRepositary) {
                    MkDirHier(fHTMLDir);
                } else {
                    MkDirHier(fTargetDir);
                }

            } catch (TDSAException &) {
                if (fHTMLRepositary) {
                    CaptureConsole("Couldn't create directory '" + fHTMLDir + "'.\n");
                } else {
                    CaptureConsole("Couldn't create directory '" + fTargetDir + "'.\n");
                }
                //WaitForKeyAndExit(1);
            }
        } else {
            CaptureConsole("Directory '" + fTargetDir + "' doesn't exist.\n");
            CaptureConsole("Specify -c to have it created.\n");

            //WaitForKeyAndExit(1);
        }
    }

    // Get environment variable: COMPUTERNAME
    char * computerName;
#if defined(FDR_OS_WINDOWS)
    computerName = getenv("COMPUTERNAME");
    if (computerName == NULL) computerName= "WINDOWS";
#else
    computerName = getenv("HOSTNAME");
    if (computerName == NULL) computerName = "LINUX" ;
#endif
    // Build path/filename for the Capture Console file.
    fInvocationTime = TOSSpecific::GetLocalTime();
    std::ostringstream timeStream;
    timeStream << std::setfill('0') << std::setw(4) << fInvocationTime.GetYear() <<
    std::setw(2) << fInvocationTime.GetMonth() <<
    std::setw(2) << fInvocationTime.GetDay() << "-" <<
    std::setw(2) << fInvocationTime.GetHour() <<
    std::setw(2) << fInvocationTime.GetMinute() <<
    std::setw(2) << fInvocationTime.GetSecond();
    //fConFileName = fTargetDir + kFileSeparator + "DSA_Output_" + timeStream.str() + ".txt";
    fConFileName = fTargetDir + kFileSeparator + "DSA_Output_" + computerName + "_" + timeStream.str() + ".log";
    // Open the console log file.
    fConsoleFile.open(fConFileName.c_str());
    if (fConsoleFile.fail()) {
        // Couldn't create the console log file, so close it & display an
        // error, but keep going.
        if (!fOEM) {
            CaptureConsole("WARNING: Couldn't open file '" + fConFileName + "' for logging.\n\n");
        } else {
            CaptureConsole("WARNING: Couldn't open file for logging.\n\n");
        }
        fConsoleFile.close();
    } else {
        //////////////////////////////////////////////////////////////////////////
        // Console logging enabled from this point forward.
        //////////////////////////////////////////////////////////////////////////
        if (!fOEM) {
            CaptureConsole("\n");
            CaptureConsole("Logging console output to file " + fConFileName + "\n");
        }

        // Put the DSA banner in the log file now that it's open.
        fConsoleFile << FDR_PRODUCTNAME " Version " FDR_VER_STRING "\n";
        fConsoleFile << FDR_LEGALCOPYRIGHT_STRING "\n\n";

        // AA052305: It's probably silly to put this into the console log file,
        // but this will make what shows up on the screen and in the file match
        // exactly.  Doing this may avoid silly questions and questionable
        // defects.
        fConsoleFile << "Loading plug-ins.\n" << std::flush;;
    }

    // Print the error logging level.
    int level = logger->GetLogThreshold();

    char *errorLevels[] = {
        "Error",
        "Warning",
        "Status",
        "Debug",
        "Verbose"
    };

    CaptureConsole("Logging level set to " + std::string(errorLevels[level]) + ".\n\n");

    // Drop the priority of the process on Windows.
#if defined(FDR_OS_WINDOWS)
    if (!::SetPriorityClass(::GetCurrentProcess(), BELOW_NORMAL_PRIORITY_CLASS)) {
        CaptureConsole("WARNING: Couldn't set priority.  Error " +
                       boost::lexical_cast<std::string>(GetLastError()) + ".\n");
    }
#endif

    std::string parseList;
    char *pluginList = getenv("DSA_INCLUDE");
    if (pluginList != NULL) {
        if (getenv("DSA_EXCLUDE") != NULL) {
            CaptureConsole("ERROR: DSA_INCLUDE and DSA_EXCLUDE can't both be set.\n\n");

            //WaitForKeyAndExit(1);
        }
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevHeavyHitter,
                std::string("DSA was run with DSA_INCLUDE = '") + pluginList + "'");
        parseList = std::string("core ") + pluginList;
        fIsPluginIncluded = true;
    } else {
        pluginList = getenv("DSA_EXCLUDE");
        if (pluginList != NULL) {
            parseList = pluginList;
            fIsPluginIncluded = false;
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevHeavyHitter,
                    std::string("DSA was run with DSA_EXCLUDE = '") + pluginList + "'");
        }
    }

    if (!parseList.empty()) {
        for (unsigned int off = 0; off < parseList.length(); ) {
            std::string::size_type delim = parseList.find_first_of(" ,;", off);
            if (delim == std::string::npos)
                delim = parseList.length();
            fCollectors.push_back(parseList.substr(off, delim-off));
            off = delim+1;
        }
    }

#if defined(FDR_OS_WINDOWS)
    dumper.SetPath(std::string(fTargetDir + "\\").c_str());
#endif

    std::string dumpXMLFilename;
    if (fWriteXMLAfterEachPlugin) {
        // Create the XML file name.
        dumpXMLFilename = fTargetDir + kFileSeparator + "DSA_Output_" + timeStream.str() + ".xml.gz";
        CaptureConsole("Writing DSA data after each plugin runs to file:\n" + dumpXMLFilename + "\n\n");
    }

    //RunProviders(dumpXMLFilename);
    RunCDMProviders(dumpXMLFilename);
    RunAnalysis(dumpXMLFilename);

    // if an output basename is not specified, generate one
    // need to generate a new basename every time
#if 0
    if (fOutputBaseName.empty()) {
        GenerateOutputBaseName();
    }
#endif
    GenerateOutputBaseName();
#ifdef PREBOOT
    //for 435429 add diagnostic result to xml.gz
    try{
	    boost::shared_ptr<NIBMDSA20::ICIMClass> pClass = workingRepositoryNamespace->GetClass("CIM_DiagnosticCompletionRecord");
	    pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), true);
	    pClass = cmpiProviderNamespace.lock()->GetClass("IBMSG_MemoryDiagLogRecord");
	    pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), true);
	}catch (TDSAException &ex){
		//... cbbcli will crash here. ignore the exception
	}
#endif
    // Create the XML file name.
    std::string xmlFilename = fTargetDir + kFileSeparator + fOutputBaseName + ".xml.gz";

    if (fXMLEnable && fFilesToDiff.size() <= 1) {
        if (!fOEM) {
            CaptureConsole("Adding " FDR_SHORTPRODUCTNAME " log entries to XML file.\n");
            CaptureConsole("Writing XML data to file " + xmlFilename + "\n");
        } else {
            CaptureConsole("Adding DSA log entries to XML file.\n");
        }
        WriteXMLOutput(outputRepositoryNamespace, xmlFilename);
    }

    AddDSALogToContainer(outputRepositoryNamespace);

    // We can safely remove the dump XML file now.
    if (!dumpXMLFilename.empty())
        ::remove(dumpXMLFilename.c_str());

    std::string htmlFilename;
    if (fHTMLEnable) {
        if (fHTMLRepositary) {
            htmlFilename = fHTMLDir + kFileSeparator;
            //hack for Linux overwriting
#if !defined(FDR_PLATFORM_WINDOWS)
            int success = system(("rm -dfr " + htmlFilename).c_str());
#endif
        } else {
            if (fWebsite)
                htmlFilename = fTargetDir + kFileSeparator;
            else
                htmlFilename = fTargetDir + kFileSeparator + fOutputBaseName;
        }

        if (!fOEM) {
            CaptureConsole("Writing HTML files to directory " + htmlFilename + "\n");
        } else {
            CaptureConsole("Writing HTML files directory \n");
        }

        try {
            TCIMContext context;
            context["filename"] = TCIMValue(htmlFilename);
            context["nNamespaces"] = TCIMValue((uint16_t)(fFilesToDiff.size() + 1));
            if (fWebsite) context["mode"] = TCIMValue("luz");
            if (IsiBMC()) context["IMM"] = TCIMValue("true");

            TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("html")->ConsumeNamespace(outputRepositoryNamespace,
                    context);
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusAccessDenied) {
                CaptureConsole("ERROR: Access denied trying to write HTML files.\n");
            } else {
                CaptureConsole(std::string("ERROR: HTML WriteContainer returned exception code ") + ex.what() + "\n");
                if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusLuzFilecopyFailure) {
                    CaptureConsole("Failure when trying to Copy dsa_sort.js file.\n");
                }
            }
            //WaitForKeyAndExit(1);
        }
    }

    std::string textFilename;
    if (fTextEnable) {
        textFilename = fTargetDir + kFileSeparator + fOutputBaseName;
        if (!fOEM) {
            CaptureConsole("Writing Text report file " + textFilename + ".txt\n");
        } else {
            CaptureConsole("Writing Text report file\n");
        }
        try {
            TCIMContext context;
            context["filename"] = TCIMValue(textFilename);
            context["nNamespaces"] = TCIMValue((uint16_t)(fFilesToDiff.size() + 1));
            if (IsiBMC()) context["IMM"] = TCIMValue("true");
            TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("text")->ConsumeNamespace(outputRepositoryNamespace,
                    context);
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusAccessDenied) {
                CaptureConsole("ERROR: Access denied trying to write Text files.\n");
            } else {
                CaptureConsole(std::string("ERROR: Text WriteContainer returned exception code ") + ex.what() + "\n");
            }
            //WaitForKeyAndExit(1);
        }
    }

    // ------------------------
    // --- EXIT THE PROGRAM ---
    // ------------------------

    //setup filenames for transfer utility
    fXmlFilename = fTargetDir + kFileSeparator + fOutputBaseName + ".xml.gz";
    //fRemoteFilename = "eserver/toibm/xseries/fdr_upload/" + fOutputBaseName + ".xml.gz";
    fRemoteFilename = fOutputBaseName;

    CaptureConsole("\nDSA capture completed successfully. \n");
    fConsoleFile.close();

    // Note: This function calls exit().
    //WaitForKeyAndExit(0);

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::Collect" );
    //CaptureConsole("Reconfiguring network\n");
    //RecycleNetwork();
    return;
}

void TCIMDataHelper::RunQuery(boost::shared_ptr<ICIMNamespace> providerNamespace,
                              boost::shared_ptr<ICIMNamespace> outputRepositoryNamespace,
                              std::string dumpXMLFilename,
                              fdrPluginType pluginType, std::string type) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::RunQuery" );

    TCIMContext context;
    std::string pluginTypeName[] = {"collector", "analyzer", "transport", "storage", "cmpi"};
    bool upcallSet = false;

    context["pluginType"] = TCIMValue((int8_t)pluginType);

    if (pluginType == fdrAnalyzer) {
        // providerNamespace->SetUpcallNamespace(outputRepositoryNamespace);
        upcallSet = true;
    }

    finishedProviders.clear();
    CaptureConsole("Running " + type + " " + pluginTypeName[pluginType] + " plug-ins pass 1.\n");
    providerNamespace->EnumerateProviders(TCollectDataFromProvider(outputRepositoryNamespace, this, false, dumpXMLFilename), context);

    //if(pluginType == fdrCollector){// && type != "CMPI") {
    // providerNamespace->SetUpcallNamespace(outputRepositoryNamespace);
    // upcallSet = true;
    //}

    finishedProviders.clear();
    CaptureConsole("Running " + type + " " + pluginTypeName[pluginType] + " plug-ins pass 2.\n");
    providerNamespace->EnumerateProviders(TCollectDataFromProvider(outputRepositoryNamespace, this, true, dumpXMLFilename), context);

    if (upcallSet) {
        //providerNamespace->SetUpcallNamespace(boost::shared_ptr<ICIMNamespace>());
    }

    boost::dynamic_pointer_cast<NIBMDSA20::TPluginManagerNamespace>(NIBMDSA20::TRootObject::GetPluginManager())->UnInitializeProviders();

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::RunQuery" );
    return;
};

void TCIMDataHelper::CaptureConsole(std::string conmsg) {
    if (fConsoleFile.is_open())
        fConsoleFile << conmsg << std::flush;

    std::cout << conmsg << std::flush;
}


class QueryInstanceExists {
public:
    QueryInstanceExists() {
        Init();
    }

    void Init() {
        fExists = false;
    }

    bool HandleInstance(boost::shared_ptr<ICIMInstance> instance) {
        fExists = true;
        return false;
    }

    bool fExists;
};


void TCIMDataHelper::AddDSALogToContainer(boost::shared_ptr<ICIMNamespace> cimNamespace) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::AddDSALogToContainer" );

    const std::string kMessageLogClassName = "IBMSG_DSAMessageLog";
    const std::string kHeavyHittersMessageLogClassName = "IBMSG_HeavyHittersMessageLog";
    const std::string kLogRecordClassName = "IBMSG_DSALogRecord";
    const std::string kHeavyHittersLogRecordClassName = "IBMSG_HeavyHittersLogRecord";
    const std::string kMessageLogName = FDR_SHORTPRODUCTNAME " core log";
    const std::string kHeavyHittersLogName = FDR_SHORTPRODUCTNAME " heavy hitters log";

    // Find the IBMSG_DSAMessageLog class.
    boost::shared_ptr<ICIMClass> coreMessageLogClass;
    try {
        coreMessageLogClass = cimNamespace->GetClass(kMessageLogClassName);
    } catch (TDSAException &ex) {
        if (ex.fStatusCode.fStatusCode != TDSAStatusCode::kDSAStatusNotFound) {
            throw ex;
        }
        CaptureConsole("ERROR: Couldn't find " + kMessageLogClassName + "\n");

        //WaitForKeyAndExit(1);
    }

    // Check to see if the core message log class already exists.
    try {
        QueryInstanceExists messageExists;

        messageExists.Init();
        coreMessageLogClass->EnumerateInstances(std::bind1st(std::mem_fun(&QueryInstanceExists::HandleInstance), &messageExists));
        if (!messageExists.fExists) {
            // Create the IBMSG_DSAMessageLog instance.
            boost::shared_ptr<ICIMInstance> instance = coreMessageLogClass->AllocateInstance();
            instance->SetPropertyValue("CreationClassName", TCIMValue(kMessageLogClassName));
            instance->SetPropertyValue("Name", TCIMValue(kMessageLogName));
            instance->AddToClass();
        }

        // Find the IBMSG_HeavyHittersMessageLog class.
        boost::shared_ptr<ICIMClass> heavyHittersMessageLogClass;
        try {
            heavyHittersMessageLogClass = cimNamespace->GetClass(kHeavyHittersMessageLogClassName);
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode != TDSAStatusCode::kDSAStatusNotFound) {
                throw ex;
            }
            CaptureConsole("ERROR: Couldn't find " + kHeavyHittersMessageLogClassName + "\n");

            //WaitForKeyAndExit(1);
        }

        // Check to see if the heavy hitters message log class already exists.
        messageExists.Init();
        heavyHittersMessageLogClass->EnumerateInstances(std::bind1st(std::mem_fun(&QueryInstanceExists::HandleInstance), &messageExists));
        if (!messageExists.fExists) {
            // Create the IBMSG_HeavyHittersMessageLog instance.
            boost::shared_ptr<ICIMInstance> instance = heavyHittersMessageLogClass->AllocateInstance();
            instance->SetPropertyValue("CreationClassName", TCIMValue(kHeavyHittersMessageLogClassName));
            instance->SetPropertyValue("Name", TCIMValue(kHeavyHittersLogName));
            instance->AddToClass();
        }

        // Copy the DSA log and the heavy hitters log to the output container.
        boost::shared_ptr<ICIMClass> coreLogClass;
        try {
            coreLogClass = cimNamespace->GetClass(kLogRecordClassName);
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode != TDSAStatusCode::kDSAStatusNotFound) {
                throw ex;
            }
            CaptureConsole("ERROR: Couldn't find " + kLogRecordClassName + "\n");

            //WaitForKeyAndExit(1);
        }

        boost::shared_ptr<ICIMClass> heavyhittersLogClass;
        try {
            heavyhittersLogClass = cimNamespace->GetClass(kHeavyHittersLogRecordClassName);
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode != TDSAStatusCode::kDSAStatusNotFound) {
                throw ex;
            }
            CaptureConsole("ERROR: Couldn't find " + kHeavyHittersLogRecordClassName + "\n");

            //WaitForKeyAndExit(1);
        }

        const std::list<ILogger::TLogEntry> &log = TRootObject::GetCoreLogger()->GetLog();
        unsigned int recordID = 0;
        for (std::list<ILogger::TLogEntry>::const_iterator it = log.begin();
                it != log.end();
                ++it, ++recordID) {
            boost::shared_ptr<ICIMInstance> instance;
            if (it->fSeverity == ILogger::kDSASevHeavyHitter) {
                instance = heavyhittersLogClass->AllocateInstance();

                // Set the CreationClassName.
                instance->SetPropertyValue("CreationClassName", TCIMValue(kHeavyHittersLogRecordClassName));

                // Set the LogName.
                instance->SetPropertyValue("LogName", TCIMValue(kHeavyHittersLogName));

                // Set the LogCreationClassName.
                instance->SetPropertyValue("LogCreationClassName", TCIMValue(kHeavyHittersMessageLogClassName));
            } else {
                instance = coreLogClass->AllocateInstance();

                instance->SetPropertyValue("Source", TCIMValue("Core"));

                // Set the type.
                instance->SetPropertyValue("Type", TCIMValue(uint16_t(it->fSeverity)));

                // Set the CreationClassName.
                instance->SetPropertyValue("CreationClassName", TCIMValue(kLogRecordClassName));

                // Set the LogName.
                instance->SetPropertyValue("LogName", TCIMValue(kMessageLogName));

                // Set the LogCreationClassName.
                instance->SetPropertyValue("LogCreationClassName", TCIMValue(kMessageLogClassName));
            }

            // Set the message.
            instance->SetPropertyValue("Message", TCIMValue(it->fMessage));

            // Set the timestamp.
            instance->SetPropertyValue("MessageTimestamp", TCIMValue(it->fTimestamp));

            // Set the record ID.
            std::stringstream x;
            x << recordID;
            instance->SetPropertyValue("RecordID", TCIMValue(x.str()));

            instance->AddToClass();
        }

        TRootObject::GetCoreLogger()->ClearLog();
    } catch (std::exception &ex) {
        CaptureConsole(std::string("ERROR: Exception ") + ex.what() + " thrown when adding " FDR_SHORTPRODUCTNAME " log entries to XML file.\n");
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::AddDSALogToContainer" );
    return;
}


void TCIMDataHelper::WriteXMLOutput(boost::shared_ptr<ICIMNamespace> cimNamespace, std::string xmlFilename) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::WriteXMLOutput, xmlFilename=" + xmlFilename );

    try {
        gzofstream file(xmlFilename.c_str(), std::ios::binary);
        if (file.fail())
            throw TDSAException(TDSAStatusCode::kDSAStatusFileSystemError);

        TXMLWriter writer(file);

        writer.WriteNamespace(cimNamespace);

        file.close();
    } catch (TDSAException &ex) {
        if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusAccessDenied) {
            CaptureConsole("ERROR: Access denied trying to write XML files.\n");
        } else {
            CaptureConsole(std::string("ERROR: XML WriteContainer returned exception code ") + ex.what() + "\n");
        }
        //WaitForKeyAndExit(1);
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::WriteXMLOutput" );
    return;
}


std::string TCIMDataHelper::GetXMLOutput(boost::shared_ptr<ICIMNamespace> cimNamespace) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::GetXMLOutput" );

    std::stringstream fileOut;
    TXMLWriter writer(fileOut);
    writer.WriteNamespace(cimNamespace);

    std::string result = fileOut.str();

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::GetXMLOutput, result=" + result );
    return result;
}


// Make a directory hierarchy.
void TCIMDataHelper::MkDirHier(const std::string &path) {
    std::vector<std::string> components;

    SplitPath(path, components, kFileSeparator, true);

    std::string dirToCreate;
    for (std::vector<std::string>::size_type i = 0; i < components.size(); ++i) {
        dirToCreate += components[i];
        if (!TOSSpecific::DirExists(dirToCreate))
            TOSSpecific::CreateDir(dirToCreate);
    }
}


// Take a path and split it into it's components.
void TCIMDataHelper::SplitPath(const std::string &path, std::vector<std::string> &components, std::string delim, bool inclDelim) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::SplitPath" );

    std::string::size_type delimIndex = 0;
    while (delimIndex < path.size()) {
        std::string::size_type newIndex = path.find(delim, delimIndex);
        if (newIndex == std::string::npos) {
            components.push_back(path.substr(delimIndex, std::string::npos));
            break;
        }
        std::string::size_type endIndex = newIndex - delimIndex;
        if (inclDelim) {
            endIndex++;
        }
        components.push_back(path.substr(delimIndex, endIndex));
        delimIndex = newIndex + 1;
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::SplitPath" );
    return;
}


std::string TCIMDataHelper::GetFileName(std::string path) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::GetFileName" );

    std::string result;
    size_t pos = path.rfind(kFileSeparator);
    result = path.substr(pos + 1, path.size() - pos - 1);

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::GetFileName, result=" + result );
    return result;
}


void TCIMDataHelper::ReadInputFile(boost::shared_ptr<NIBMDSA20::ICIMNamespace> ns,
                                   std::string filename) {
    try {
        TNamespacePopulator::PopulateFromXMLFile(ns, filename);
    } catch (TDSAException &ex) {
        if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusFileNotFound) {
            CaptureConsole("ERROR: File '" + filename + "' not found.\n");
        } else {
            CaptureConsole(static_cast<std::string>("ERROR: PopulateContainerFromFile returned exception code ") + ex.what() + "\n");
        }
        //WaitForKeyAndExit(1);
    }

    std::string verString = TCIMSchemaHelper::GetDataSourceMajorVersion(ns);
    int ver = atoi(verString.c_str());
}

void TCIMDataHelper::SetupLogging() {
    // Initialize the logger.
    TLogger::Initialize();
    // Set the error logging level.
    logger = TRootObject::GetCoreLogger();
    logger->SetLogThreshold(ILogger::EDSALogSeverity(0));
    char *logLevel = getenv("DSA_LOGLEVEL");
    if (logLevel != NULL && logLevel[0]!='\0' && logLevel[1]=='\0' && isdigit(logLevel[0])) {
        ILogger::EDSALogSeverity levelIndex = ILogger::EDSALogSeverity(atoi(logLevel));
        if (levelIndex <= ILogger::kDSASevVerbose && levelIndex >= ILogger::kDSASevError)
            logger->SetLogThreshold(levelIndex);
    }

    // Set the error logging file.
    char* logFile = getenv("DSA_LOGFILE");
    try {
        if (logFile != NULL)
            logger->SetLogFilename(TOSSpecific::RelocateRelativePath(execDir, logFile));
    } catch (TDSAException &) {
        CaptureConsole(static_cast<std::string>("ERROR: Could not open log file, ") + std::string(logFile) + "\n");
        //WaitForKeyAndExit(1);
    }
}

//Cleans Up shared pointers
void TCIMDataHelper::ClearInstances() {
    providerNamespace.lock()->ClearInstances();
    outputRepositoryNamespace->ClearInstances();
    providerNamespaceRepository->ClearInstances();
}

void TCIMDataHelper::LoadProvidersNSPs() {
    TCIMContext context;
    std::vector<std::string> nsps = TOSSpecific::FindNSPs();
    for (std::vector<std::string>::iterator it = nsps.begin(); it != nsps.end(); it++)
        TOSSpecific::LoadNSPLibrary(*it);

    // -- Allocate union nsp
    try {
        unionNamespaceRepository = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("inmem")->AllocateNamespace();
        TCIMContext unionNamespaceContext;
        unionNamespaceContext.insert(std::make_pair("repository", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&unionNamespaceRepository))));
        fUnionNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("union")->AllocateNamespace(unionNamespaceContext);
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating union namespace. Reason = ") + ex.what() + "\n");
    }

    // --- Create the output repository namespace ---
    try {
        if (fpropOverwrite) {
            outputRepositoryNamespace =
                TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider(kOutputRepositoryNamespaceName)->AllocateNamespace(context,true);
        } else {
            outputRepositoryNamespace =
                TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider(kOutputRepositoryNamespaceName)->AllocateNamespace();
        }
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating repository namespace. Reason = ") + ex.what() + "\n");
    }
    // --- Create the provider namespace ---
    try {
        providerNamespaceRepository =
            TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider(kProviderNamespaceRepositoryName)->AllocateNamespace();
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating repository namespace. Reason = ") + ex.what() + "\n");
    }

    TCIMContext providerNamespaceContext;
    providerNamespaceContext.insert(std::make_pair("repository", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&providerNamespaceRepository))));
    providerNamespaceContext.insert(std::make_pair("upcall", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&fUnionNamespace))));
    providerNamespaceContext.insert(std::make_pair("output", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&outputRepositoryNamespace))));
    try {
        providerNamespace =
            TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider(kProviderNamespaceName)->AllocateNamespace(providerNamespaceContext);
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating collector namespace. Reason = ") + ex.what() + "\n");
    }
    fUnionNamespace->AddUnderlyingNamespace(providerNamespace.lock());
}

void TCIMDataHelper::LoadCDMProvidersNSPs() {
    // -- Create CMPI Namespace Provider
    try {
        cmpiProviderNamespaceRepository = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("inmem")->AllocateNamespace(TCIMContext());
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating cmpi repository namespace. Reason = ") + ex.what() + "\n");
    }

    TCIMContext cmpiProviderNamespaceContext;
    cmpiProviderNamespaceContext.insert(std::make_pair("repository", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&cmpiProviderNamespaceRepository))));
    cmpiProviderNamespaceContext.insert(std::make_pair("upcall", NIBMDSA20::TCIMValue(reinterpret_cast<uint64_t>(&fUnionNamespace))));
    try {
        cmpiProviderNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("cmpi")->AllocateNamespace(cmpiProviderNamespaceContext);
    } catch (TDSAException &ex) {
        CaptureConsole(std::string("Failed allocating cmpi namespace. Reason = ") + ex.what() + "\n");
    }
    fUnionNamespace->AddUnderlyingNamespace(cmpiProviderNamespace.lock());
    //a temp repository for diagnosticcompletionrecords
    workingRepositoryNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider(kOutputRepositoryNamespaceName)->AllocateNamespace(TCIMContext());
    TCIMCopy::CopyClasses(fUnionNamespace, workingRepositoryNamespace, true);
    CaptureConsole("Copying Schema...\n");
    TCIMCopy::CopyClasses(fUnionNamespace, outputRepositoryNamespace, false);
    boost::shared_ptr<NIBMDSA20::ICIMClass> pClass = fUnionNamespace->GetClass("IBMSG_DSAProduct");
    pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), false);
    CaptureConsole("\n");
}

void TCIMDataHelper::LoadHTTPProvidersNSP() {
    NIBMDSA20::SPLibrary *splibrary = NIBMDSA20::SPLibrary::GetSplibraryInstance(0);
    if (splibrary->IsiBMCMachine()) {

        TCIMContext ibmcContext;
        ibmcContext.insert(std::make_pair("pluginNameQualDeclValue", NIBMDSA20::TCIMValue("IMM")));
        ibmcProviderNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("IMM")->AllocateNamespace();
        try {
            httpProviderNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("cimhttp")->AllocateNamespace(ibmcContext);
            boost::dynamic_pointer_cast<NIBMDSA20::TCimHTTPNamespace>(httpProviderNamespace)->connect(boost::dynamic_pointer_cast<NIBMDSA20::TIBMCNamespace>(ibmcProviderNamespace)->GetHost(),boost::dynamic_pointer_cast<NIBMDSA20::TIBMCNamespace>(ibmcProviderNamespace)->GetUser(),boost::dynamic_pointer_cast<NIBMDSA20::TIBMCNamespace>(ibmcProviderNamespace)->GetPass());
            ibmcProviderNamespace->AddUnderlyingNamespace(httpProviderNamespace);
            fUnionNamespace->AddUnderlyingNamespace(ibmcProviderNamespace);
            TCIMCopy::CopyClasses(httpProviderNamespace, outputRepositoryNamespace, true);
#if !defined (FDR_OS_WINDOWS)
            boost::dynamic_pointer_cast<NIBMDSA20::TCimHTTPNamespace>(httpProviderNamespace)->setTimeout(300000);
#endif
            fHTTP=true;
        } catch (TDSAException &e) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"TCIMDataHelper::LoadHTTPProvidersNSP - Something went wrong loading HTTP NSP" );
            fHTTP=false;
            //Unload module for inband
            system("rmmod rndis_host >/dev/null 2>&1");
        }
    } else {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"TCIMDataHelper::LoadHTTPProvidersNSP - Not IMM Machine" );
    }
#ifndef FDR_OS_WINDOWS
    if (isxHypMachine()) {
        LoadxHypProvidersNSP();
    }
#endif
}

#ifndef FDR_OS_WINDOWS
void TCIMDataHelper::LoadxHypProvidersNSP() {
    TCIMContext xHypContext;
    xHypContext.insert(std::make_pair("pluginNameQualDeclValue", NIBMDSA20::TCIMValue("xHypCIMOM")));
    xHypVirtProviderNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("xHypCIMOM")->AllocateNamespace();
    try {
        httpProviderNamespace = TRootObject::GetNamespaceProviderManager()->GetNamespaceProvider("cimhttp")->AllocateNamespace(xHypContext, false, "root/virt");
        boost::dynamic_pointer_cast<NIBMDSA20::TCimHTTPNamespace>(httpProviderNamespace)->connect(boost::dynamic_pointer_cast<NIBMDSA20::TXHYPNamespace>(xHypVirtProviderNamespace)->GetHost(),boost::dynamic_pointer_cast<NIBMDSA20::TXHYPNamespace>(xHypVirtProviderNamespace)->GetUser(),boost::dynamic_pointer_cast<NIBMDSA20::TXHYPNamespace>(xHypVirtProviderNamespace)->GetPass());
        xHypVirtProviderNamespace->AddUnderlyingNamespace(httpProviderNamespace);
        fUnionNamespace->AddUnderlyingNamespace(xHypVirtProviderNamespace);
        TCIMCopy::CopyClasses(httpProviderNamespace, outputRepositoryNamespace, true);
        boost::dynamic_pointer_cast<NIBMDSA20::TCimHTTPNamespace>(httpProviderNamespace)->getPegClient()->setTimeout(300000);
        // fHTTP=true; ibmc indicator
    } catch (TDSAException &e) {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"TCIMDataHelper::LoadxHypProvidersNSP - Something went wrong loading HTTP NSP" );
        // fHTTP=false; ibmc only
		#if !defined(FDR_OS_WINDOWS)
		//Unload module for inband
		system("rmmod rndis_host >/dev/null 2>&1");
		#endif 
    }
}

bool TCIMDataHelper::isxHypMachine() {
    try {
        system("cat /etc/issue > xhyprunning.txt 2>&1");
        std::string fxhyprunning = NIBMDSA20::TOSSpecific::CaptureFile("xhyprunning.txt");
        system("rm -f xhyprunning.txt");
        if (fxhyprunning.find("Virtualization Hypervisor") != string::npos)
        {
            stringstream debug;
            debug << "TCIMDataHelper:isxHypMachine  found Virtualization Hypervisor.\n";
            NIBMDSA20::TRootObject::GetCoreLogger()->OutputLogEntry(NIBMDSA20::ILogger::kDSASevDebug, debug.str());
            return true;
        }
        else
        {
            stringstream debug;
            debug << "TCIMDataHelper:isxHypMachine  Not Virtualization Hypervisor.\n";
            NIBMDSA20::TRootObject::GetCoreLogger()->OutputLogEntry(NIBMDSA20::ILogger::kDSASevDebug, debug.str());
            return false;
        }
    } catch (std::exception &ex) {
        stringstream debug;
        debug << "TCIMDataHelper:isxHypMachine cat /etc/issue exception " << ex.what() << ".\n";
        NIBMDSA20::TRootObject::GetCoreLogger()->OutputLogEntry(NIBMDSA20::ILogger::kDSASevDebug, debug.str());
        return false;
    }
}
#endif

void TCIMDataHelper::RunProviders(std::string dumpXMLFilename) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::RunProviders, dumpXMLFilename=" + dumpXMLFilename );

    try {
        RunQuery(providerNamespace.lock(), outputRepositoryNamespace, dumpXMLFilename, fdrCollector, "DSA");
    } catch (TDSAException &ex) {
        CaptureConsole(static_cast<std::string>("ERROR: RunQuery returned exception code ") + ex.what() + "\n");
    }

    // AA100604: Special hack for Chris McCann: put the MTM in the XML in
    // a well known place.  This hack will go away once we can give him a
    // command line tool to extract the MTM (and handle Netfinity boxes, etc.)
    try {
        boost::shared_ptr<ICIMClass> pClass = outputRepositoryNamespace->GetClass(TCIMSchemaHelper::GetSystemCreationClassName(outputRepositoryNamespace));
        TEnumerateSystemCreation enumerator;

        pClass->EnumerateInstances(std::bind1st(std::mem_fun(&TEnumerateSystemCreation::HandleInstance), &enumerator));

        if (enumerator.fFirstInstance) {
            try {
                TCIMValue val = TCIMValue(std::string("{CMCMTM}") + TCIMSchemaHelper::GetMTM(outputRepositoryNamespace));
                enumerator.fFirstInstance->SetPropertyValue("CMCMTM", val);
            } catch (TDSAException &) {
                // No MTM-- do nothing.
            }
        }
    } catch (TDSAException &ex) {
        if (ex.fStatusCode.fStatusCode != TDSAStatusCode::kDSAStatusNotFound) {
            throw ex;
        }
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::RunProviders" );
    return;
}

void TCIMDataHelper::RunCDMProviders(std::string dumpXMLFilename) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::RunCDMProviders, dumpXMLFilename=" + dumpXMLFilename );

    try {
        RunQuery(fUnionNamespace, outputRepositoryNamespace, dumpXMLFilename, fdrCollector, "DSA");
        RunQuery(fUnionNamespace, outputRepositoryNamespace, dumpXMLFilename, fdrCMPI, "DSA");
    } catch (TDSAException &ex) {
        CaptureConsole(static_cast<std::string>("ERROR: RunQuery returned exception code ") + ex.what() + "\n");
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::RunCDMProviders" );
    return;
}

std::string TCIMDataHelper::EnumerateDiagTests(std::string view,bool interact) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::EnumerateDiagTests, view=" + view );

    TDiagsRunner *diagsrunner = TDiagsRunner::GetDiagsRunner(fUnionNamespace);
    std::string theRet = diagsrunner->EnumerateDiagTests(view);

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::EnumerateDiagTests, theRet=" + theRet );
    return theRet;
}

std::string TCIMDataHelper::ExecuteDiagTest(std::string testID, std::string settingData,bool interact) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::ExecuteDiagTest, testID=" + testID + ", settingData=" + settingData );
    TDiagsRunner *diagsrunner = TDiagsRunner::GetDiagsRunner(fUnionNamespace);
    std::string theRet = diagsrunner->Execute(testID,settingData,workingRepositoryNamespace);

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::ExecuteDiagTest, theRet=" + theRet );
    return theRet;
}

std::string TCIMDataHelper::GetExtendedResults(std::string testID,bool interact) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::GetExtendedResults, testID=" + testID );

    TDiagsRunner *diagsrunner = TDiagsRunner::GetDiagsRunner(fUnionNamespace);
    std::string theRet = diagsrunner->ExtendedResults(testID,workingRepositoryNamespace);

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::GetExtendedResults, theRet=" + theRet );
    return theRet;
}

std::string TCIMDataHelper::EnumerateTestSettings(std::string testID,bool interact) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::EnumerateTestSettings, testID=" + testID );

    TDiagsRunner *diagsrunner = TDiagsRunner::GetDiagsRunner(fUnionNamespace);
    std::string theRet = diagsrunner->EnumerateTestSettings(testID);
    TCIMContext context;
    context["pageID"] = TCIMValue("DiagsSetting");
    context["testID"] = TCIMValue(testID);
    if (interact) {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::EnumerateTestSettings, theRet=" + theRet );
        return theRet;
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::EnumerateTestSettings" );
    //return TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("htmldatahelper")->GetData(outputRepositoryNamespace,providerNamespace.lock(), cmpiProviderNamespace.lock(), TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), 4, context);
    return TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("htmldatahelper")->GetData(outputRepositoryNamespace, fUnionNamespace, TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), 4, context);
}

void TCIMDataHelper::RunAnalysis(std::string dumpXMLFilename) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::RunAnalysis, dumpXMLFilename=" + dumpXMLFilename );

    try {
        //RunQuery(providerNamespace.lock(), outputRepositoryNamespace, dumpXMLFilename, fdrAnalyzer, "DSA");
        RunQuery(fUnionNamespace, outputRepositoryNamespace, dumpXMLFilename, fdrAnalyzer, "DSA");
    } catch (TDSAException &ex) {
        CaptureConsole(static_cast<std::string>("ERROR: RunQuery returned exception code ") + ex.what() + "\n");
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::RunAnalysis" );
}

std::string TCIMDataHelper::GetHTMLPage(std::string pageID) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::GetHTMLPage, pageID=" + pageID );

    TCIMContext context;
    std::string theRet;
    context["pageID"] = TCIMValue(pageID);

    if ( pageID != "CriticalDetails" ) {
        outputRepositoryNamespace->ClearInstances();
        boost::shared_ptr<NIBMDSA20::ICIMClass> pClass = providerNamespace.lock()->GetClass("IBMSG_DSAProduct");
        pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), true);
    }

    try {
        if ( pageID == "DiagsFull" ) {
            boost::shared_ptr<NIBMDSA20::ICIMClass> pClass = workingRepositoryNamespace->GetClass("CIM_DiagnosticCompletionRecord");
            pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), true);
            pClass = cmpiProviderNamespace.lock()->GetClass("IBMSG_MemoryDiagLogRecord");
            pClass->EnumerateInstances(TAddInstanceToOutputRepositoryNamespace(workingRepositoryNamespace), true);
            theRet = CheckString(TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("htmldatahelper")->GetData(workingRepositoryNamespace,fUnionNamespace, TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), 5, context));
        } else {
            if ((pageID == "IMMConfig" || pageID == "Environmentals") && fHTTP) {
                context["nspID"] = TCIMValue("IMM");
            }
            theRet = CheckString(TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("htmldatahelper")->GetData(outputRepositoryNamespace, fUnionNamespace, TAddInstanceToOutputRepositoryNamespace(outputRepositoryNamespace), 0, context));
        }
    } catch (TDSAException &ex) {
        CaptureConsole(static_cast<std::string>("ERROR: GetHTML returned exception code ") + ex.what() + "\n");
        theRet = "";
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::GetHTMLPage, theRet=" + theRet );
    return theRet;
}

void TCIMDataHelper::TransferToIBM() {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::TransferToIBM" );

    bool goTransfer=true;
    // Create the XML file name.
    //std::string remoteFilename =fOutputBaseName;

    std::string remoteFilename = "eserver/toibm/xseries/fdr_upload/" + fOutputBaseName + ".xml.gz";

    char *outputDir;
    int isoem = IsOEM();
    if (isoem==false) {
        outputDir= "/var/log/IBM_Support/";
        system("mkdir -p /var/log/IBM_Support");
    } else {
        outputDir= "/var/log/OEM_Support/";
        system("mkdir -p /var/log/IBM_Support");
    }
    char *resultsFile = FindOutputFile(outputDir, ".xml.gz");

    if (resultsFile == NULL) {
        CaptureConsole("Collection must be run before performing transfer.\n\n");
        return;
    }
    if (!fOEM) {
        fXmlFilename.assign(resultsFile);
        free(resultsFile);
        CaptureConsole("Writing XML data to file " + fXmlFilename + "\n");
    } else {
        fXmlFilename.assign(resultsFile);
        free(resultsFile);
        CaptureConsole("Writing XML data to file\n");
    }
    WriteXMLOutput(outputRepositoryNamespace, fXmlFilename);
    if (fXmlFilename=="") {
        CaptureConsole("Collection must be run before performing transfer.\n\n");
        return;
    } else {
        CaptureConsole("\n\n");
        CaptureConsole("                              ***************\n");
        if (!fOEM) {
            CaptureConsole("Attempted data upload to IBM by means of an unencrypted channel will\n");
        } else {
            CaptureConsole("Attempted data upload by means of an unencrypted channel will\n");
        }
#ifndef FDR_OS_MCP_PPC
        CaptureConsole("proceed in 10 seconds.  Press any key to cancel the attempted upload.\n");
#else
        CaptureConsole("proceed in 10 seconds.  Press the 'c' key to cancel the upload.\n");
#endif
        CaptureConsole("                              ***************\n");
        for (int i = 0; i < 10; ++i) {
            if (TOSSpecific::IsKeyWaiting()) {
#ifndef FDR_OS_MCP_PPC
                // Key pressed-- eat it.
                TOSSpecific::GetKeyboardChar();
                CaptureConsole("\nUpload cancelled.\n");
                goTransfer=false;
                break;
#else
                // Key pressed-- eat it.
                int keyval = TOSSpecific::GetKeyboardChar();
                if (keyval == 0x63 || keyval == 0x43) {
                    CaptureConsole("\nUpload cancelled.\n");
                    goTransfer=false;
                    break;
                }
                TOSSpecific::USleep(1000);
#endif
            } else {
                // Wait for 1 sec.
                TOSSpecific::USleep(1000);
            }
            CaptureConsole(".");
        }
        if (goTransfer) {
            //CaptureConsole("\nConfiguring Network Controllers.\n");
            RecycleNetwork(true);
            if (!fOEM) {
                CaptureConsole("\nTransferring collected data to IBM Service.\n");
            } else {
                CaptureConsole("\nTransferring collected data.\n");
            }
            try {
                std::string serverURL;
                if (fIBMFtpAddress != "")
                    serverURL = fIBMFtpAddress;
                else
                    serverURL = "testcase.boulder.ibm.com";
                //std::cout << "serverURL = " << serverURL << std::endl;
                if (TOSSpecific::FTPFile(serverURL,fXmlFilename, remoteFilename)) {
                    CaptureConsole("Transfer complete.\n");
                } else {
                    CaptureConsole("Transfer failed.\n");
                }
            } catch (TDSAException &ex) {
                if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusConnectionFailed) {
                    if (!fOEM) {
                        CaptureConsole("ERROR: Couldn't connect to IBM Service.\n");
                    } else {
                        CaptureConsole("ERROR: Couldn't connect to Service.\n");
                    }
                } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusAccessDenied) {
                    CaptureConsole("ERROR: Couldn't transfer to FTP server, file may already exist.\n");
                } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusINETNotFound) {
                    CaptureConsole("ERROR: Couldn't establish Internet connection.\n");
                } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusLibCurlFailure) {
                    CaptureConsole("ERROR: Couldn't load curl library, verify that libcurl.so is installed.\n");
                } else {
                    CaptureConsole(std::string("ERROR: FTPFile threw exception ") + ex.what() + ".\n");
                }
            }
        }

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::TransferToIBM" );
        return;
    }
}


std::string TCIMDataHelper::TransferToIBM2(const std::string &infilename) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::TransferToIBM2" );

    bool goTransfer=true;
    // Create the XML file name.
    //std::string remoteFilename = fOutputBaseName;

    std::string remoteFilename = "eserver/toibm/xseries/fdr_upload/" + fOutputBaseName + ".xml.gz";

    std::string results;

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "input xml file name: " + infilename);
    if (fXmlFilename=="") {
        if (infilename.find("NotFound") != std::string::npos)
            return "Collection must be run before performing transfer";
        fXmlFilename = infilename;
        std::string::size_type pos = 0, prev_pos = 0;
        while (pos != std::string::npos) {
            pos ++;
            prev_pos = pos;
            pos = infilename.find("/", pos);
        }
        //remoteFilename = fOutputBaseName;
        remoteFilename = "eserver/toibm/xseries/fdr_upload/" + infilename.substr(prev_pos);

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "remoteFilename = " + remoteFilename);
    }
//  else
    {
        if (!fOEM) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Writing XML data to file " + fXmlFilename );
        } else {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Writing XML data to file");

        }
        WriteXMLOutput(outputRepositoryNamespace, fXmlFilename);

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Configuring Network Controllers" );
        RecycleNetwork(true);

        if (!fOEM) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transferring collected data to IBM Service" );
        } else {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transferring collected data" );
        }

        try {
            std::string serverURL;
            if (fIBMFtpAddress != "")
                serverURL = fIBMFtpAddress;
            else
                serverURL = "testcase.boulder.ibm.com";
            //std::cout << "serverURL = " << serverURL << std::endl;
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "remoteFilename = " + remoteFilename);

            if (TOSSpecific::FTPFile(serverURL,fXmlFilename, remoteFilename)) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transfer complete" );
                results = "Transfer complete";
            } else {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transfer failed" );
                results = "Transfer failed";
            }
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusConnectionFailed) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not connect to IBM Service" );
                if (!fOEM) {
                    results = "ERROR: Could not connect to IBM Service";
                } else {
                    results = "ERROR: Could not connect to Service";
                }
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusAccessDenied) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Couldn't transfer to FTP server, file may already exist" );
                results = "ERROR: Couldn't transfer to FTP server, file may already exist";
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusINETNotFound) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not establish Internet connection" );
                results = "ERROR: Could not establish Internet connection";
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusLibCurlFailure) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not load curl library, verify that libcurl.so is installed" );
                results = "ERROR: Could not load curl library, verify that libcurl.so is installed";
            } else {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: FTPFile threw exception " + std::string( ex.what() ) );
                results = "ERROR: FTPFile threw exception " + std::string( ex.what() );
            }
        }

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::TransferToIBM2" );
        return results;
    }
}

void TCIMDataHelper::DSAeiHttp() {
    if (fHTTP) {
        TDiagsRunner diagsrunner = TDiagsRunner(ibmcProviderNamespace);
        diagsrunner.EIHTTP();
    }
}

void TCIMDataHelper::DSAiBMCRestart() {
    if (fHTTP) {
        //boost::dynamic_pointer_cast<NIBMDSA20::TIBMCNamespace>(ibmcProviderNamespace)->IBMCReset();
    }
}

std::string TCIMDataHelper::TransferToUserFTP(std::string ftpaddress, int port) {
#ifndef FDR_OS_WINDOWS
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::TransferToUserFTP" );

    bool goTransfer=true;

    std::string results;

    char *outputDir;
    int isoem = IsOEM();
    if (isoem==false) {
        outputDir= "/var/log/IBM_Support/";
        system("mkdir -p /var/log/IBM_Support");
    } else {
        outputDir= "/var/log/OEM_Support/";
        system("mkdir -p /var/log/IBM_Support");
    }
    char *resultsFile = FindOutputFile(outputDir, ".xml.gz");

    if (resultsFile == NULL) {
        CaptureConsole("Collection must be run before performing transfer. \n.\n");
        return "Collection must be run before performing transfer";
    } else {
        if (!fOEM) {
            fXmlFilename.assign(resultsFile);
            free(resultsFile);
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Writing XML data to file " + fXmlFilename );
        } else {
            fXmlFilename.assign(resultsFile);
            free(resultsFile);
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Writing XML data to file");

        }
        WriteXMLOutput(outputRepositoryNamespace, fXmlFilename);

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Configuring Network Controllers" );
        //CaptureConsole("\nConfiguring Network Controllers.\n");
        RecycleNetwork();

        if (!fOEM) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transferring collected data to user ftp" );
        } else {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transferring collected data" );
        }

        CaptureConsole("\nTransferring Collected Data To User Customized FTP Server .\n");

        /* Modify the address to supported format */
        std::stringstream finaladdr;
        std::string tmpaddr=ftpaddress;
        //remove 'ftp://'
        size_t npos=tmpaddr.find("ftp://");
        tmpaddr = tmpaddr.substr(npos+6);
        //add port number to ip tail
        finaladdr<<":";
        finaladdr<<port;
        //insert port number to ip
        npos=tmpaddr.find("/");
        if (npos == std::string::npos)
            tmpaddr.insert(tmpaddr.length(),finaladdr.str());
        else
            tmpaddr.insert(npos, finaladdr.str());
        //remove the last '/'
        npos = tmpaddr.rfind("/");
        if (npos!=std::string::npos&&npos ==(tmpaddr.length()-1))
            tmpaddr.erase(tmpaddr.length()-1,1);

        try {
            int OutputDirLen;
            int OutputFileLen;
            OutputDirLen = strlen(outputDir);
            fOutputBaseName= fXmlFilename.substr(OutputDirLen );
            OutputFileLen = fOutputBaseName.size();
            fOutputBaseName=fOutputBaseName.substr(0,(OutputFileLen-7));
            //      if (TOSSpecific::FTPFile(tmpaddr,fXmlFilename, fOutputBaseName))
            if (TOSSpecific::UserFTPFile(tmpaddr, fXmlFilename, fOutputBaseName)) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transfer complete" );
                CaptureConsole("Transferring Completed .\n");
                results = "Transfer complete";
            } else {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Transfer failed" );
                CaptureConsole("Transfer Failed .\n");
                results = "Transfer failed";
            }
        } catch (TDSAException &ex) {
            if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusConnectionFailed) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not connect to user ftp" );
                if (!fOEM) {
                    results = "ERROR: Could not connect to user ftp";
                } else {
                    results = "ERROR: Could not connect to Service";
                }
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusTransferFailure) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Couldn't transfer to FTP server, file may already exist" );
                results = "ERROR: Couldn't transfer to FTP server, file may already exist";
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusINETNotFound) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not establish Internet connection" );
                results = "ERROR: Could not establish Internet connection";
            } else if (ex.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusLibCurlFailure) {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: Could not load curl library, verify that libcurl.so is installed" );
                results = "ERROR: Could not load curl library, verify that libcurl.so is installed";
            } else {
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "ERROR: UserFTPFile threw exception " + std::string( ex.what() ) );
                results = "ERROR: FTPFile threw exception " + std::string( ex.what() );
            }
            //CaptureConsole(results);
        }

        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::TransferToUserFTP" );
        return results;
    }
#else
	return "";
#endif
}


void TCIMDataHelper::DSAei(std::string className) {
    TDiagsRunner diagsrunner = TDiagsRunner(fUnionNamespace);
    diagsrunner.EI(className);
}

void TCIMDataHelper::GenerateOutputBaseName() {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::GenerateOutputBaseName" );

    // Get machine type model from container
    std::string machineTypeModel;
    try {
        //machineTypeModel = TCIMSchemaHelper::GetMTM(providerNamespace.lock());
        machineTypeModel = TCIMSchemaHelper::GetMTM(fUnionNamespace);
    } catch (TDSAException &) {
        machineTypeModel = "Unknown";

        // Log an error in the DSA error log that the MTM was invalid.
        std::string invalidString;
        try {
            //invalidString = TCIMSchemaHelper::GetRawMTMString(providerNamespace.lock());
            invalidString = TCIMSchemaHelper::GetRawMTMString(fUnionNamespace);
        } catch (TDSAException &) {
            invalidString = "<NULL>";
        }
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError,
                std::string("Invalid MTM string '") + invalidString + "'.");
    }

    // Get serial number from container
    std::string serialNumber;
    try {
        //serialNumber = TCIMSchemaHelper::GetSerialNumber(providerNamespace.lock());
        serialNumber = TCIMSchemaHelper::GetSerialNumber(fUnionNamespace);
    } catch (TDSAException &) {
        serialNumber = "Unknown";

        // Log an error in the DSA error log that the serial number was invalid.
        std::string invalidString;
        try {
            //invalidString = TCIMSchemaHelper::GetRawSerialNumberString(providerNamespace.lock());
            invalidString = TCIMSchemaHelper::GetRawSerialNumberString(fUnionNamespace);
        } catch (TDSAException &) {
            invalidString = "<NULL>";
        }
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError,
                std::string("Invalid serial number '") + invalidString + "'.");
    }

    // Create the basename to write the output to
    std::ostringstream timeStream;
    timeStream << std::setfill('0') << std::setw(4) << fInvocationTime.GetYear() <<
    std::setw(2) << fInvocationTime.GetMonth() <<
    std::setw(2) << fInvocationTime.GetDay() << "-" <<
    std::setw(2) << fInvocationTime.GetHour() <<
    std::setw(2) << fInvocationTime.GetMinute() <<
    std::setw(2) << fInvocationTime.GetSecond();
    fOutputBaseName = machineTypeModel + "_" + serialNumber + "_" + timeStream.str();

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::GenerateOutputBaseName" );
    return;
}

std::string TCIMDataHelper::CheckString(std::string inString) {

    if (inString.empty())
        return inString;
    for (unsigned int i=0; i<inString.length(); i++) {
        if (inString[i]<(char)32 || inString[i]>(char)126) inString[i]=' ';
    }
    return inString;
}

void TCIMDataHelper::SetDisplayedProviders(std::string provName) {
    finishedProviders.push_back(provName);
}

std::vector<std::string> TCIMDataHelper::ParseChoice(std::string stringIn) {
    std::string space=",";
    std::vector<std::string> theVector;
    std::string::size_type isSpace = stringIn.find(space);
    while (isSpace != std::string::npos) {
        std::string theOption;
        theOption.assign(stringIn,1,isSpace-1);
        stringIn.erase(0,isSpace+1);
        isSpace = stringIn.find(space);
        theVector.push_back(theOption);
    }
    return theVector;
}

std::vector<std::vector<std::string> > TCIMDataHelper::ParseTests(std::string stringIn) {
    std::string comma=",";
    std::string pipe="|";
    std::string::size_type isComma = stringIn.find(comma);
    while (isComma != std::string::npos) {
        std::vector<std::string> theArray;
        std::string theName;
        std::string theDevice;
        std::string theElementName;
        theName.assign(stringIn,0,isComma);
        stringIn.erase(0,isComma+1);
        isComma = stringIn.find(comma);
        if (isComma != std::string::npos) {
            theDevice.assign(stringIn,0,isComma);
            stringIn.erase(0,isComma+1);
            std::string::size_type isPipe = stringIn.find(pipe);
            theElementName.assign(stringIn,0,isPipe);
            stringIn.erase(0,isPipe+1);
            theArray.push_back(theName);
            theArray.push_back(theDevice);
            theArray.push_back(theElementName);
            fTestVector.push_back(theArray);
            isComma = stringIn.find(comma);
        }
    }
    return fTestVector;
}

void TCIMDataHelper::ListTests(std::vector<std::vector<std::string> > vectorIn)
{
  uint32_t i;
  uint32_t k=0;
  uint32_t maxLine=50;
  uint32_t stringSize;
  uint32_t size_vector = vectorIn.size();
  std::cout<<"\nDiagnostic Tests:\n";
  std::cout<<"--------------------------------------------------------------------------------------------------\n";
  for (i=0; i<size_vector;i++)
  {
    std::vector<std::string>::iterator iType = vectorIn[i].begin();
    std::stringstream outString;
    if((iType[0].find("Tape Drive:") != std::string::npos) && !iType[2].empty())
    {   
        std::string strTmp = iType[0]; 
            strTmp = strTmp.substr(10);
        strTmp = iType[2] + strTmp;
        outString << i+1 << " "<<strTmp<<" : "<<iType[1];
    }   
    else        
    {           
        outString << i+1 << " "<<iType[0]<<" : "<<iType[1];
    }           
    std::cout<<outString.str();
    stringSize = outString.str().size();
    for (unsigned int j=stringSize;j<maxLine;j++)
    {           
      std::cout<<" ";
    }
    i++;
    if (i<size_vector)
    {
      std::vector<std::string>::iterator kType = vectorIn[i].begin();
     if((kType[0].find("Tape Drive:") != std::string::npos) && !kType[2].empty())
      {
        std::string strTmp = kType[0];
        strTmp = strTmp.substr(10);
        strTmp = kType[2] + strTmp;
        std::cout<<i+1<<" "<<strTmp<<" : "<<kType[1]<<std::endl;
      }
      else
      {
        std::cout<<i+1<<" "<<kType[0]<<" : "<<kType[1]<<std::endl;
      }
    }
    k++;
    if (k == 40)
    {
      k=0;
      std::cout << std::endl << "Please press ANY key to Continue ..." << std::endl ;
      while (!TOSSpecific::IsKeyWaiting())
      {
        continue;
      }
      TOSSpecific::GetKeyboardChar();
      std::cout << std::endl;
    }
  }
}

int TCIMDataHelper::RunAutomation() {
    std::string theAlternateFile;
#if !defined(FDR_OS_WINDOWS)
    theAlternateFile = "cat /proc/cmdline > /dsa/cmdline";
#endif
    if (system(theAlternateFile.c_str())==-1) {
        std::cout<<"script cat error"<<std::endl;
    }

    //Get the file contents
    std::string theKernelParameters;
#if defined(FDR_OS_WINDOWS)
    if (ReadFile("c:\\cmdline", theKernelParameters)==1) {
#else
    if (ReadFile("/dsa/cmdline", theKernelParameters)==1) {
#endif
        return 1;
    }
    std::string theIPParameter = theKernelParameters;
    std::string theAddParameter = theKernelParameters;
    std::string theDSAAddress = "scriptserver";
    std::string theDSAPath = "scriptpath";
    std::string theAddress;
    std::string thePath;
    std::cout<<"DSA is running with the Kernel Parameters: "<<std::endl;
    std::cout<<theKernelParameters<<std::endl;
    //First check for address param
    std::string::size_type isParam = theIPParameter.find(theDSAAddress);
    if (isParam != std::string::npos) {
        theIPParameter.erase(0,isParam);
        std::string::size_type isEqual = theIPParameter.find("=");
        if (isEqual != std::string::npos) {
            theIPParameter.erase(0,isEqual+1);
            std::string::size_type isSpace = theIPParameter.find(" ");
            if (isSpace != std::string::npos) {
                theAddress.assign(theIPParameter,0,isSpace);
            } else {
                theAddress = theIPParameter;
            }
        } else {
            return 1;
        }
        //Begin find the file param
        std::string::size_type isParam = theAddParameter.find(theDSAPath);
        if (isParam != std::string::npos) {
            theAddParameter.erase(0,isParam);
            std::string::size_type isEqual = theAddParameter.find("=");
            if (isEqual != std::string::npos) {
                theAddParameter.erase(0,isEqual+1);
                std::string::size_type isSpace = theAddParameter.find(" ");
                if (isSpace != std::string::npos) {
                    thePath.assign(theAddParameter,0,isSpace);
                } else {
                    thePath = theAddParameter;
                }
            } else {
                return 1;
            }
        }
    } else {
        return 1;
    }
    //End find the addr
    //End Get file contents
    //Get Just IP for screen display purposes
    std::string theDisplayAddress = theAddress;
    std::string::size_type isAt = theIPParameter.find("@");
    if (isAt != std::string::npos) {
        theDisplayAddress.erase(0,isAt+1);

    }
    //Go and get the script file from remote machine
    std::string curFileName = NIBMDSA20::TOSSpecific::GetDSARootPath();
    std::string localPath;
#if defined(FDR_OS_WINDOWS)
    localPath = curFileName + "\\data\\prebootscript";
#else
    localPath = curFileName + "/data/prebootscript";
#endif
    if (TOSSpecific::FTPFileFromIBM(theAddress, localPath, thePath)) {
        std::cout<<"DSA has retrieved Test Script from FTP Server: "<<theDisplayAddress<<std::endl;
        //End get the script file from remote machine
        //Begin parsing preboottest.xml
        std::string curPath;
#if defined(FDR_OS_WINDOWS)
        curPath = curFileName + "\\data\\preboottests.xml";
#else
        curPath = curFileName + "/data/preboottests.xml";
#endif
        unsigned int fileSize = (unsigned int) NIBMDSA20::TOSSpecific::GetFileSize(curPath);
        boost::scoped_ptr<char> xmlDocument(new char[fileSize]);
        if (xmlDocument == NULL)
            throw NIBMDSA20::TDSAException(NIBMDSA20::TDSAStatusCode::kDSAStatusOutOfMemory);
        FILE *xmlfile = fopen(curPath.c_str(), "r");
        if (xmlfile == NULL)
            return 1;

        fread(xmlDocument.get(), 1, static_cast<size_t>(fileSize), xmlfile);
        fclose(xmlfile);
        TPrebootTestParser *parser = new TPrebootTestParser();
        parser->Parse(xmlDocument.get());
        fTestsMap = parser->GetRequestedData();
        delete parser;
        //End parsing preboottest.xml
        //Before checking the script, run a dos2unnix on it
        //std::string theCmd = "dos2unix " + thePath;
        std::string theCmd = "dos2unix " + localPath;
        if (system(theCmd.c_str())==-1) {
            std::cout<<"dos2unix error"<<std::endl;
        }
        //Get the contents of the script
        std::string theScriptFile;
        if (ReadFile(localPath, theScriptFile)==1) {
            return 1;
        }
        std::string::size_type isEndLine = theScriptFile.find(' ');
        while (isEndLine != std::string::npos) {
            std::string testNumber;
            testNumber.assign(theScriptFile,0,isEndLine);
            if (testNumber=="")
                break;
            theScriptFile.erase(0,isEndLine+1);
            fTestsToRun.push_back(testNumber);
            isEndLine = theScriptFile.find(' ');
        }
        //End Get the contents of the script
        //Open a file to write test results to
        std::string logFile;
#if defined(FDR_OS_WINDOWS)
        logFile = curFileName + "\\data\\autoLog.txt";
#else
        logFile = curFileName + "/data/autoLog.txt";
#endif
        FILE * hFile = OpenFile(logFile);

        //End Open file
        //Check Memlog for Error or Abort, and halt if true
        bool memLogOK = false;
        boost::shared_ptr<NIBMDSA20::ICIMClass> theClass;
        std::vector<boost::shared_ptr<NIBMDSA20::ICIMInstance> > instancesVector;
        try {
      	    NIBMDSA20::TCIMContext context; 
            context["nspID"] = NIBMDSA20::TCIMValue("cmpi"); 
            theClass = fUnionNamespace->GetClass("IBMSG_MemoryDiagLogRecord",context);
            theClass->EnumerateInstances(NIBMDSA20::TAddInstancesToVectorCallback(instancesVector));
            for (unsigned int i=0; i<instancesVector.size(); i++) {
                std::string memType = instancesVector[i]->GetProperty("Type")->ToString();
                std::string memMessage = instancesVector[i]->GetProperty("Message")->ToString();
                std::string logMessage = memType + " : " + memMessage + "\n\n";
                std::cout<<logMessage<<std::endl;
                if (memType.find("Error")!=std::string::npos || memType.find("Abort")!=std::string::npos) {
                    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RunAutomation - MemLog Is Error/Abort");
                    WriteFile(hFile,logMessage);
                    break;
                }
                memLogOK = true;
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RunAutomation - MemLog Is Pass");
                WriteFile(hFile,logMessage);
            }
        } catch (TDSAException &e) {
            if (e.fStatusCode.fStatusCode == TDSAStatusCode::kDSAStatusNotFound) {
                std::string logMessage = "MemoryLog Status Not Found";
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RunAutomation - MemoryLog Status Not Found");
                WriteFile(hFile,logMessage);
            } else {
                throw e;
            }
        }
        if (memLogOK) {
            //Beginning Running Tests
            bool testError = false;
            fTestVector.clear();
            ParseTests(EnumerateDiagTests("normal"));
            for (uint32_t i = 0; i<fTestsToRun.size(); i++) {
                std::map<std::string,std::string >::const_iterator iMap = fTestsMap.find(fTestsToRun[i]);
                if (iMap != fTestsMap.end() && !testError) {
                    for (uint32_t j = 0; j<fTestVector.size(); j++) {
                        if (fTestVector[j].begin()[0] == iMap->second) {
                            std::string initMsg = fTestVector[j].begin()[0] + " : " + fTestVector[j].begin()[1] + "\n";
                            WriteFile(hFile,initMsg);
                            std::cout<<initMsg<<std::endl;
                            std::string exeMsg = ExecuteDiagTest((fTestVector[j]).begin()[0]+","+(fTestVector[j]).begin()[1]+","+(fTestVector[j]).begin()[2],"normal") + "\n";
                            WriteFile(hFile,exeMsg);
                            std::cout<<exeMsg<<std::endl;
                            std::string resultMsg = GetExtendedResults((fTestVector[j]).begin()[0]+","+(fTestVector[j]).begin()[1]+","+(fTestVector[j]).begin()[2]) + "\n" + "\n";
                            WriteFile(hFile,resultMsg);
                            std::cout<<resultMsg<<std::endl;
                            if (exeMsg.find("Pass")==std::string::npos) {
                                testError = true;
                                break;
                            }
                        }
                    }
                } else {
                    break;
                }
            }
        }
        CloseFile(hFile);
        //ftp the log results back to server
        //have to get the path from where we got the script from
        std::string tmpPath = thePath;
        std::string resFile;
        std::string::size_type isSlash = tmpPath.find("/");
        while (isSlash != std::string::npos) {
            std::string tmpStr;
            tmpStr.assign(tmpPath,0,isSlash+1);
            tmpPath.erase(0,isSlash+1);
            resFile = resFile + tmpStr;
            isSlash = tmpPath.find("/");
        }
        // Get serial number from container
        std::string serialNumber;
        try {
            serialNumber = TCIMSchemaHelper::GetSerialNumber(providerNamespace.lock());
        } catch (TDSAException &) {
            serialNumber = "Unknown";
        }
        resFile = resFile + serialNumber + ".txt";
        if (RecycleNetwork()) {
            if (TOSSpecific::FTPFile(theAddress,logFile,resFile)) {
                std::cout<<"DSA has copied the test results to FTP Server: "<<theDisplayAddress<<std::endl;
            } else {
                std::cout<<"DSA has failed to copy the test results to FTP Server: "<<theDisplayAddress<<std::endl;
            }
            //end ftp log
            return 0;
        }
    }//End FTP from
    else {
        std::cout<<"DSA has failed to retrieved Test Script from FTP Server: "<<theDisplayAddress<<std::endl;
    }
    //delete the script we copied over
    std::string theDel;
#if defined(FDR_OS_WINDOWS)
    theDel = "del " + localPath;
#else
    theDel = "rm " + localPath;
#endif
    if (system(theDel.c_str())==-1) {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RunAutomation - prebootscript delete error");
    }
    //end delete the script we copied over
    return 1;
}

/*
  * NetworkAvailable(const char *hostname) for preboot only
  * Check if the network connection to target hostname is available
  * If DNS is failed, this function report failed,
  * If no physical link is available, this funcition report failed
  *
  * Return Value:
  * 1 = connection ok
  * 0 = connection failed
  */

unsigned int TCIMDataHelper::NetworkAvailable(const char *hostname) {
#ifndef FDR_OS_WINDOWS
    struct hostent *hp;
    unsigned int ret;

    if ((hp=gethostbyname(hostname))==NULL) {
        //fIBMFtpAddress
        std::vector<std::string> param;
        std::size_t cpos;
        int i = 0;
        std::string bufferOutput;
        param.push_back(hostname);
        param.push_back("-c 3");
        bufferOutput = NIBMDSA20::TOSSpecific::SpawnProcess("ping", param);
        if ((cpos = bufferOutput.find("bytes from ")) != std::string::npos) {
            //ping work, extract the ip address to fIBMFtpAddress
            std::size_t end_pos;
            //erase the bytes from
            bufferOutput.erase(0,cpos+10);
            //find the : or ):, then
            end_pos = bufferOutput.find("):");
            if (end_pos == std::string::npos)
                end_pos = bufferOutput.find(":");
            //get the sub string
            bufferOutput = bufferOutput.substr(0,end_pos);
            //if hostname contains, erase it
            if ((end_pos = bufferOutput.find(hostname))!=std::string::npos)
                bufferOutput.erase(0,end_pos+strlen(hostname));
            //if ( contains, erase it
            if ((end_pos = bufferOutput.find("("))!=std::string::npos)
                bufferOutput.erase(0,end_pos+1);
            //get rid of the space
            while (bufferOutput[i] == ' ') {
                bufferOutput.erase(0,1);
                i++;
            }
            //std::cout << "buffer before = " << bufferOutput << std::endl;


            //set the fIBMFtpAddress
            fIBMFtpAddress = bufferOutput;
            //std::cout << std::endl << "remote IBM ip =" << fIBMFtpAddress << std::endl;
            ret = 1;
        } else if (bufferOutput.find("unknown host") != std::string::npos) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Route to remote host unavailable, need to reset");
            ret = 0;
        } else {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Remote host unreachable, need to reset");
            ret = 0;
        }
    } else {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevStatus, "Network is ok, download index.xml should be OK");
        ret = 1;
    }
    return ret;
#else
	return 0;
#endif
}
bool TCIMDataHelper::RecycleNetwork(bool isTransfer) {
    /*bool pidFound = false;
    std::string thePid;
    //Get the PID of dhclient
    std::string theGrep = "ps | grep dhclient > /dsa/grepResults";
    if(system(theGrep.c_str())==-1){
      TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - ps grep error");
      return false;
    }
    std::string dhClientFile;
    if(ReadFile("/dsa/grepResults", dhClientFile)==1){
      TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - dhclient read error");
      return false;
    }
    //Delete the file
    if(system("rm -f /dsa/grepResults")==-1){
      TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - grep result rm error");
    }
    std::string::size_type isFound = dhClientFile.find("dhclient");
    if(isFound != std::string::npos){
      std::string::size_type isSpace = dhClientFile.find(' ');
      if(isSpace != std::string::npos){
        thePid.assign(dhClientFile,0,isSpace);
        std::cout<<thePid<<std::endl;
        pidFound = true;
      }
    }
    else{
      return false;
    }
    //Kill dhclient process
    if(pidFound){
      std::string theKill = "kill -9 " + thePid + ">/dev/null 2>&1";
      if(system(theKill.c_str())==-1){
        std::string psErr = "TCIMDataHelper::RecycleNetwork - Error Killing PID " + thePid;
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, psErr);
        return false;
      }
    }*/
    //Stop and start network services
    if (isTransfer) {
        std::vector<std::string> param;
        std::string bufferOutput;
        std::vector<std::string> foundNics;
        std::string sNic;
        param.push_back("--netcard");
        bufferOutput = NIBMDSA20::TOSSpecific::SpawnProcess("hwinfo", param);
        std::string::size_type isParam = bufferOutput.find("Device File:");
        while (isParam != std::string::npos) {
            bufferOutput.erase(0,isParam+13);
            sNic.assign(bufferOutput,0,4);
            //determine if this nic has link
            {
                std::string niclink;
                std::string::size_type npoz = bufferOutput.find("Link detected: ");
                if (npoz !=std::string::npos) {
                    niclink = bufferOutput.substr(npoz,20);
                    if (niclink.find("yes")!=std::string::npos) {
                        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "Got a Nic has physical link");
                        if (sNic!="usb0") {
                            foundNics.push_back(sNic);
                        }
                    }
                }
            }
            isParam = bufferOutput.find("Device File:");
        }
        //if no link available, just return
        if (foundNics.size() == 0) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError, "Not physical connection is available on machine(s)");
            return false;
        }

        std::string lastNic = "";
        //sort the vector to avoid eth* reversed
        sort(foundNics.begin(),foundNics.end());
        //int i = 0;
        for (std::string::size_type iNic =0; iNic <foundNics.size();)

        {

            if (NetworkAvailable("testcase.boulder.ibm.com")) {
                break;
            } else { //network is not ok, need to reset

                std::stringstream errmsg;
                //tried this nic before, just ignore and move to the next one
                if (lastNic == foundNics[iNic]) {
                    iNic++;
                    lastNic = "";
                    continue;
                } else {
                    lastNic = foundNics[iNic];
                }
                errmsg<<"RecycleNetwork configured for: " <<foundNics[iNic] <<  " for 2 times";
                TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, errmsg.str());

                for (unsigned int ryctimes=0; ryctimes<2; ryctimes++) {
                    if (system("/etc/init.d/network stop >/dev/null 2>&1")==-1) {
                        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - network service stop error");
                        return false;
                    }
                    if (system("/etc/init.d/network start >/dev/null 2>&1")==-1) {
                        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - network service start error");
                        return false;
                    }
                    //run dhclient
                    std::stringstream sDhEther;
                    sDhEther << "dhclient "<<foundNics[iNic]<<" >/dev/null 2>&1";
                    std::stringstream errmsg;
                    errmsg<<"TCIMDataHelper::RecycleNetwork configured for: " <<sDhEther.str();;
                    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, errmsg.str());

                    //		CaptureConsole("\nConfiguring Network Controllers.\n");
                    if (system((sDhEther.str()).c_str())==-1) {
                        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError, "Failed in dhclient, still try");
                        continue;
                    }
                }
            }
        }


    } else {
        if (system("/etc/init.d/network stop >/dev/null 2>&1")==-1) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - network service stop error");
            return false;
        }
        if (system("/etc/init.d/network start >/dev/null 2>&1")==-1) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - network service start error");
            return false;
        }
        //run dhclient
        if (system("dhclient -cf /tmp/embed/data/dhclient.conf >/dev/null 2>&1")==-1) {
            TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::RecycleNetwork - dhclient error");
            return false;
        }
    }
    return true;
}

std::string TCIMDataHelper::GetpTapeCapacity(){
    std::string TapeCapContents="";
    std::string TapeCapFile="/tmp/embed/tapeCap.tmp";


    if (1==ReadFile(TapeCapFile,TapeCapContents)) {
	std::cout<<"DSA has failed to retrieved Tape Capacity"<<std::endl;  
	TapeCapContents="";
	return TapeCapContents;
    }
	else
	{
	       
		std::cout<<"DSA has  retrieved Tape Capacity:"<<TapeCapContents<<std::endl;	
		TapeCapContents=TapeCapContents+'\0';
		return TapeCapContents;

	}
	
        return TapeCapContents;
	
	
}
int TCIMDataHelper::ReadFile(std::string fileName, std::string &fileContents) {
    //Get the file contents
    FILE *kernelfile = fopen(fileName.c_str(), "r");
    long lSize;
    char * buffer;
    size_t result;
    if (kernelfile==NULL) {
        return 1;
    }
    fseek (kernelfile , 0 , SEEK_END);
    lSize = ftell (kernelfile);
    rewind (kernelfile);
    buffer = (char*) malloc (sizeof(char)*lSize);
    if (buffer == NULL) {
        fclose (kernelfile);
        free (buffer);
        return 1;
    }
    result = fread (buffer,1,lSize,kernelfile);
    fclose (kernelfile);
    fileContents = CheckString(buffer);
    free (buffer);
    return 0;
}

FILE* TCIMDataHelper::OpenFile(std::string fileName) {
    FILE * pFile;
    pFile = fopen (fileName.c_str(),"w");
    return pFile;
}

int TCIMDataHelper::CloseFile(FILE * pFile) {
    fclose (pFile);
    return 0;
}

int TCIMDataHelper::WriteFile(FILE * pFile, std::string fileContents) {
    if (pFile!=NULL) {
        fputs (fileContents.c_str(),pFile);
    }
    return 0;
}

std::vector<std::vector<std::string> > *TCIMDataHelper::GetTestVector() {
    return &fTestVector;
}

char* TCIMDataHelper::FindOutputFile(char *parentPath,char* ext) {
#ifndef FDR_OS_WINDOWS
// std::cout << "Entering TCIMDataHelper::FindOutputFile, ext=" << ext << std::endl;
    DIR *dir;
    struct dirent *entry;
    struct stat entry_stat;
    time_t latestTime = 0;
    char latestFilename[128];
    char path[512];
    char *filename;
    int parentPathLen;
    parentPathLen = strlen(parentPath);
    memcpy(path,parentPath,parentPathLen);
    filename = path + parentPathLen;
    dir = opendir(parentPath);
    if (dir==NULL) {
        //printf("Source folder not exists!");
        return NULL;
    }


    while ((entry = readdir(dir))) {
        int namelen = strlen(entry->d_name);
        // check extension
        if (0 != strcmp(ext, entry->d_name + namelen - strlen(ext))) {
            continue;
        }
        // construct full path and stat
        strcpy(filename, entry->d_name);
        if (stat(path, &entry_stat) == -1) {
            continue;
        }
        if (S_ISDIR(entry_stat.st_mode)) {
            continue;
        }

        // check if this is the latest one
        if (latestTime < entry_stat.st_mtime) {
            strcpy(latestFilename, entry->d_name);
            latestTime = entry_stat.st_mtime;
        }
    }

    if (latestTime == 0) {
        return NULL;
    } else {
        char *ret =(char *)malloc(parentPathLen + strlen(latestFilename) + 1);
        memcpy(ret, parentPath, parentPathLen);
        strcpy(ret + parentPathLen, latestFilename);
        // std::cout << "Exiting TCIMDataHelper::FindOutputFile, result=" << ret << std::endl;
        return ret;
    }
#else
	return "";
#endif
}
bool TCIMDataHelper::IsOEM() {
#ifndef FDR_OS_WINDOWS
    std::string theGrep = "ls";
    std::vector<std::string> params;
    params.push_back("docs");
    std::string theResult = TOSSpecific::SpawnProcess(theGrep, params);
    std::string::size_type isFound = theResult.find("oem");
    if (isFound==std::string::npos) {
        return false;
    } else {
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug, "TCIMDataHelper::IsIEM - TRUE");
        return true;
    }
#else
	return false;
#endif
}

bool TCIMDataHelper::IsiBMC() {
    return fHTTP;
}

long TCIMDataHelper::ButtonChecker(std::string buttonName) {
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Entering TCIMDataHelper::ButtonChecker, buttonName=" + buttonName  );
    // std::cout << "Entering TCIMDataHelper::ButtonChecker, buttonName=" << buttonName << std::endl;
    TCIMContext context;
    std::string retVal;
    long theRet;
    std::vector<boost::shared_ptr<ICIMInstance> > vec_inst;
    context["ButtonName"] = TCIMValue(buttonName);
    context["pageID"] = TCIMValue(buttonName);
    if (buttonName=="ServProcConfig") {
        if (IsiBMC()) {
            return 0;
        }
        return 1;
    } else if (buttonName=="IMMConfig") {
        if (IsiBMC()) {
            return 1;
        }
        return 0;
    } else if (buttonName=="SPLogs") {
        if (IsiBMC()) {
            return 0;
        }
        return 1;
    } else if (buttonName=="IMMLogs") {
        if (IsiBMC()) {
            return 1;
        }
        return 0;
    } else if (buttonName=="BIST") {
        if (IsiBMC()) {
            return 0;
        }
        return 1;
    } else if (buttonName=="IMMBIST") {
        if (IsiBMC()) {
            return 1;
        }
        return 0;
    } else if (buttonName == "Emulex"||buttonName == "Qlogic"||buttonName=="DriveHealth"||buttonName == "SRaid") {
        boost::shared_ptr<NIBMDSA20::ICIMClass> pClass;
        std::vector<boost::shared_ptr<NIBMDSA20::ICIMInstance> > instancesVector;
        std::vector<std::string> ClassVec;
        if (buttonName == "Emulex") {
            ClassVec.push_back("ELXHBA_Product");
        } else if (buttonName == "Qlogic") {
            ClassVec.push_back("IBMSG_QLogicIScsiRawData");
            ClassVec.push_back("IBMSG_QLogicFibreChannelRawData");
        } else if (buttonName == "DriveHealth") {
            ClassVec.push_back("OMC_ATADevice");
            ClassVec.push_back("IBMSG_TapeDriveSensePageData");
            ClassVec.push_back("IBMSG_IDESMARTUseOfMessageLog");
        } else if (buttonName == "SRaid") {
            ClassVec.push_back("IBMSG_srSCSIProtocolController");
        }

        for (unsigned int i=0; i<ClassVec.size(); i++) {
            instancesVector.clear();
            CaptureConsole(static_cast<std::string>("Query -")+ClassVec[i].c_str()+"\n");
            try {
                if ((ClassVec[i] == "OMC_ATADevice") || (ClassVec[i] == "OMC_IDESMARTErrorLog") || (ClassVec[i] == "OMC_IDESMARTAttrib") || (ClassVec[i] == "ELXHBA_Product")) {
                    pClass = cmpiProviderNamespace.lock()->GetClass(ClassVec[i].c_str());
                } else {
                    pClass = fUnionNamespace->GetClass(ClassVec[i].c_str());
                }

                pClass->EnumerateInstances(NIBMDSA20::TAddInstancesToVectorCallback(instancesVector));
                if (instancesVector.empty()) {
                    CaptureConsole(static_cast<std::string>("Button ")+buttonName.c_str()+" should not be shown\n");
                    theRet = 0;
                } else {
                    CaptureConsole(static_cast<std::string>("Button ")+buttonName.c_str()+" should be shown\n");
                    theRet = 1;
                    break;//break out in case found one here, no more loop is needed
                }
            } catch (TDSAException &ex) {
                CaptureConsole(static_cast<std::string>("ERROR: Button Checker  returned exception code ") + ex.what() + "\n");
                theRet = 0;
                retVal = "false";
            }
        }
        return theRet;
    } else {
        try {
            TNamespaceConsumerManager::GetInstance()->GetNamespaceConsumer("htmldatahelper")->GetData(outputRepositoryNamespace,fUnionNamespace, TAddInstancesToVectorCallback(vec_inst), 0, context);
        } catch (TDSAException &ex) {
            CaptureConsole(static_cast<std::string>("ERROR: GetHTML returned exception code ") + ex.what() + "\n");
            retVal = "false";
        }

        if ( vec_inst.empty() )
            theRet = 0;
        else {
            theRet = 1;
        }
    }

    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevDebug,"Exiting TCIMDataHelper::ButtonChecker, theRet=" + theRet );
    return theRet;
}

/****************************************************************************/
/*                                                                          */
/*  Name:  cimdatahelper.cpp                                                */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* FUNCTION: Command line client.                                           */
/*                                                                          */
/*                                                                          */
/* CHANGE ACTIVITY                                                          */
/* $  =Reason    Version         YYMMDD Userid    Comments                  */
/*  -- --------  --------------  ------ --------  ----------------          */
/*     441073                    101708 xzz2654   Reset the collection      */
/*                                                options.                  */
/*     459626                    021909 shekharj  updated buttonchecker for */
/*                                                DriveHealth, qlogic etc.  */
/****************************************************************************/

extern void getType11(char embedVersion[]);
/*
* HelperUpdateIsSupport
* Return:
* 0 -- support update
* 1 -- not support --no option
* -1 -- failed in function -- no option
*/
int  TCIMDataHelper::HelperUpdateIsSupport() {
#ifndef FDR_OS_WINDOWS
    //first of all, check if  /tmp/preboot220/preboot/update existed
    //if not, boot from internal USB key, just return 1
    char *updatedirpoint = getenv("DSA_UPDATE_DIR");
    std::string updatedir = updatedirpoint?updatedirpoint:"";
    std::string MachineTypeModel;
    int rc;
    struct stat _stat;
    rc = stat(updatedir.c_str(), &_stat);
    //no update directory, says not support
    if (rc<0)
        return 1;
    try {
        MachineTypeModel = TCIMSchemaHelper::GetMTM(providerNamespace.lock()).substr(0,4);
    } catch (TDSAException &ex) {
        std::string errorMsg(static_cast<std::string>("ERROR: Detecting machine type with error =  ") + ex.what() + "\n");
        std::cout << errorMsg << std::endl;
        TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError, errorMsg);
        return -1;
    }
    TRootObject::GetCoreLogger()->OutputLogEntry(ILogger::kDSASevError, "TCIMDataHelper::HelperUpdateIsSupport MT = "+MachineTypeModel);
    //determine if is supported machine type
    if (MachineTypeModel == "7141"||
            MachineTypeModel == "7143"||
            MachineTypeModel == "7144"||
            MachineTypeModel == "7233"||
            MachineTypeModel == "7234"||
            MachineTypeModel == "8014"||
            MachineTypeModel == "8028"||
            MachineTypeModel == "1916"||
            MachineTypeModel == "7901"||
            MachineTypeModel == "7902") {
        return 0;
    } else
        return 1;
#else
	return 0;
#endif
}

/*
*
*HelperUpdateVersionInfo
* Return:
* 0   -- up-to-date
* 1   -- existed embed version is older,
* 2   -- existed embed version is higher,
* -1 -- failed in function
*
*/

int TCIMDataHelper::HelperUpdateVersionInfo() {
#ifndef FDR_OS_WINDOWS
    char embedVerSMB[16]={0};
    std::string embedVerFile;
    std::string UpdateMarkFile="/tmp/emVer";
    int res,cmplength;

    if (1==ReadFile(UpdateMarkFile,embedVerFile)) {
        getType11(embedVerSMB);
        embedVerFile = embedVerSMB;
    }

    //Show the version Info for user
    std::cout << std::endl << "The Embed pDSA Version Is: " << embedVerFile << std::endl;
    std::cout << "The Target pDSA Version On Bootable Media Is: " << cDSAVersion << std::endl;
    cmplength=cDSAVersion.length()>embedVerFile.length()?embedVerFile.length():cDSAVersion.length();
    res = strncmp(cDSAVersion.c_str(), embedVerFile.c_str(),cmplength);

    if (res == -1)
        return 2;
    else
        return res;
#else
	return 0;
#endif
}


/*
*
*HelperUpdateProceedxFlash
* Return:
* 0   -- Success
* 1   -- Failed
*
*/
int TCIMDataHelper::HelperUpdateProceedxFlash() {
    int res;
    char buf[128];
    sprintf(buf, "cd %s;./lflash64 -z;cd /tmp/embed",getenv("DSA_UPDATE_DIR"));
    res = system(buf);

    if (res == 0) {
        //Mark the Current version
        memset(buf,0,128);
        sprintf(buf, "echo %s>/tmp/emVer", cDSAVersion.c_str());
        system(buf);
        return 0;
    } else
        return 1;
}

