/*************************************************************************
*
* TCIMDATAHELPER.H - Command line client.
*
* Copyright (C) 2004-2005 IBM Corporation
*
*************************************************************************/

#if !defined(_TCIMDATAHELPER_H)
#define _TCIMDATAHELPER_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "ICIMNamespace.h"
#include "TCIMDateTime.h"
#include "pluginmgr.h"
#include "ILogger.h"
#include "TLogger.h"
#include "TPrebootTestParser.h"
#include "../../nsp/cmpi/TCMPIClass.h"

class EXPORT_CLASS TCollectDataFromProvider;

class EXPORT_CLASS TCIMDataHelper {
public:
   TCIMDataHelper();
   ~TCIMDataHelper();
   static TCIMDataHelper* GetCIMDataHelper();
   static void FreeCIMDataHelper();
   void SetupLogging();
   void SetupProviderConfig();
   void ClearInstances();
   void LoadProvidersNSPs();
   void LoadCDMProvidersNSPs();
   void LoadHTTPProvidersNSP();
   #ifndef FDR_OS_WINDOWS
   void LoadxHypProvidersNSP();
   #endif
   void RunProviders(std::string dumpXMLFilename);
   void RunCDMProviders(std::string dumpXMLFilename);
   std::string EnumerateDiagTests(std::string view,bool interact=false);
   std::string ExecuteDiagTest(std::string testID, std::string settingData,bool interact=false);
   std::string GetExtendedResults(std::string testID,bool interact=false);
   std::string EnumerateTestSettings(std::string testID,bool interact=false);
   void RunAnalysis(std::string dumpXMLFilename);
   std::string GetHTMLPage(std::string pageID);
   void TransferToIBM();
   std::string TransferToIBM2(const std::string &);
   std::string TransferToUserFTP(std::string ftpaddress, int port);

   void DSAei(std::string className);
   void DSAeiHttp();
   void GenerateOutputBaseName();
   void Collect(std::vector<std::string> inOptions = std::vector<std::string>());
   //void WaitForKeyAndExit(int rc);
   //void Exit(int rc);
   void RunAllPlugins(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace, bool getAssociations, std::string dumpXMLFilename);
   void RunQuery(boost::shared_ptr<NIBMDSA20::ICIMNamespace> inputNamespace, 
                 boost::shared_ptr<NIBMDSA20::ICIMNamespace> outputNamespace,
                 std::string dumpXMLFilename,
                 NIBMDSA20::fdrPluginType pluginType, std::string type);
   void RunUXPlugin(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace, const std::string pathForUX);
   void RunBasicAnalPlugin(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace);
   void RunPCIAnalPlugin(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace);
   void CaptureConsole(std::string conmsg);
   void WriteXMLOutput(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace, std::string xmlFilename);
   std::string GetXMLOutput(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace);
   void AddDSALogToContainer(boost::shared_ptr<NIBMDSA20::ICIMNamespace> cimNamespace);
   void MkDirHier(const std::string &path);
   void SplitPath(const std::string &path, std::vector<std::string> &components, std::string delim, bool inclDelim);
   std::string GetFileName(std::string path);
   void ReadInputFile(boost::shared_ptr<NIBMDSA20::ICIMNamespace> ns, std::string filename);
   std::string CheckString(std::string inString);
   void SetDisplayedProviders(std::string provName);
   int ReadFile(std::string fileName, std::string &fileContents);
   FILE* OpenFile(std::string fileName);
   int CloseFile(FILE * pFile);
   int WriteFile(FILE * pFile, std::string fileContents);
   char* FindOutputFile(char *parentPath,char* ext);
   int RunAutomation();
   bool RecycleNetwork(bool isTransfer=false);
   unsigned int NetworkAvailable(const char *hostname);
   bool IsOEM();
   bool IsiBMC();
   std::string GetpTapeCapacity();
   void DSAiBMCRestart();
   std::vector<std::vector<std::string> > ParseTests(std::string stringIn);
   std::vector<std::string> ParseChoice(std::string stringIn);
   void ListTests(std::vector<std::vector<std::string> > vectorIn);

   boost::shared_ptr<NIBMDSA20::ICIMNamespace> outputRepositoryNamespace;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> workingRepositoryNamespace;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> providerNamespaceRepository;
   boost::weak_ptr<NIBMDSA20::ICIMNamespace> providerNamespace;

   boost::shared_ptr<NIBMDSA20::ICIMNamespace> cmpiProviderNamespaceRepository;
   boost::weak_ptr<NIBMDSA20::ICIMNamespace> cmpiProviderNamespace;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> httpProviderNamespace;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> ibmcProviderNamespace;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> unionNamespaceRepository;
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> fUnionNamespace;
   #ifndef FDR_OS_WINDOWS
   boost::shared_ptr<NIBMDSA20::ICIMNamespace> xHypVirtProviderNamespace;
   bool isxHypMachine();
   #endif
   std::vector<std::vector<std::string> > *GetTestVector();
   long ButtonChecker(std::string buttonName);
   //Interface for Update Function
   int  HelperUpdateIsSupport();
   int HelperUpdateVersionInfo();
   int HelperUpdateProceedxFlash();

private:
   TCIMDataHelper(TCIMDataHelper &other);
   TCIMDataHelper &operator=(TCIMDataHelper &other);

   std::string fTargetDir;
   std::string fInputFile;
   std::string fOutputBaseName;
   std::string fIBMFtpAddress;
   std::string fUpdateExpressPath;
   std::string fConFileName;
   std::vector<std::string> fFilesToDiff;
   std::string fDiffSpecFilename;
   std::string fHTMLDir;
   //DSA version for preboot
   std::string cDSAVersion;
   
   NIBMDSA20::TCIMDateTime fInvocationTime;

  std::string fXmlFilename;
  std::string fRemoteFilename;

   // Stream to log console to.
   std::ofstream fConsoleFile;

   bool fCreateDir;
   bool fBatchMode;
   bool fXMLEnable;
   bool fTextEnable;
   bool fHTMLEnable;
   bool fWebsite;
   bool fHelpRequested;
   bool fWriteXMLAfterEachPlugin;
   bool fDiagsEnable;
   bool fCmpiEnable;
   bool fpropOverwrite;
   bool fHTMLRepositary;
   bool fOEM;
   bool fHTTP;

   //std::string execDir;

   // List of collectors to include/exclude.
   std::vector<std::string> fCollectors;
   // List of collectors already displayed
   std::vector<std::string> finishedProviders;
   bool fIsPluginIncluded;

   std::map<std::string,std::string > fTestsMap;
   std::vector<std::string > fTestsToRun;
   std::vector<std::vector<std::string> > fTestVector;

   friend class TCollectDataFromProvider;

   //static TCIMDataHelper *fSingleton;
};

#endif

