/*************************************************************************
*
* DSACLI.H - Command line client.
*
* Copyright (C) 2004-2007 IBM Corporation
*
*************************************************************************/
#if !defined(_TDSACLI_H)
#define _TDSACLI_H
#include <string>
#include <fstream>
#include <map>
#include "ICIMNamespace.h"
#include "TDSAException.h"
#include "cimdatahelper.h"

struct CmdLineArguments
{
   std::string command;
   std::string component; //device
   std::string action;    //test
   bool isDestructiveEnabled;
};  


class TDsaCli
{
public:
    TDsaCli();
	virtual	~TDsaCli();
    int Main(int argc, char **argv);
    void CaptureConsole(std::string conmsg);
    void WaitForKeyAndExit(int rc);
    int GetCLIData (int argc, char **argv);
    std::string usage();
	std::string GetHTMLPage(std::string pageID);
	std::string EnumerateDiagTests(std::string view);
	std::string EnumerateTestSettings(std::string testID);
	std::string ExecuteDiagTest(std::string testID, std::string settingData);
	std::string GetExtendedResults(std::string testID);
	void CollectData();
	void TransferToIBM();
	void TransferToUserFTP();

	void DSAei(std::string classNameIn);
	void RunInteractive();
	//Datacollection subroutine
	std::string SubDataCollectionUsage();
	void SubDataCollection();
	//Diagnostic
	std::string SubDiagnosticUsage();
	void SubDiagnostic();
	void SubDiagnosticExecute();
	bool SubDiagnosticBuildTapeRWTestParam(int &tapeRWLBA, int &tapeRWBSP, std::string devId);
	void SubDiagnosticExtendResult();
	//Copy subroutine
	void SubCopyResult();
	int SubCopyDetermineMedia();
	int SubCopyCopyFile(std::string src, std::string dst);
	int SubCopyCopyTree(std::string src, std::string dst);
	int SubCopyMountMedia(std::string dev, std::string &dstPath);
	int SubCopyUnmountMedia(std::string dstPath);
	int SubCopyOrgnizePartition(int index1, char * deviceValue);
	
	std::string Interusage();
	std::string CollectOptionsChoice();
	std::string CollectOptions();

	void View();
	int findTextOutput(std::string &buf); 
	int findXmlOutput(std::string &buf);
	int findHtmlOutput(std::string & buf);
	std::string findLatestFile(char *parentPath, char *ext);
	int launchTextEditor(std::string args);
	int fileExists(std::string name); 
	int dirExists(std::string name);
	static void* ExecuteInThread(void* job);
	void printStatus();
	void InitialThread();

private:
    //Stream to log console to.
    std::ofstream fConsoleFile;
	std::string fConFileName;
	//Data Helper Object
	TCIMDataHelper *helper;
	bool interactive;
	bool fSol;
	bool fOEM;
};


class TDsaCliArgs
{
public:
    TDsaCliArgs();
    static CmdLineArguments parse(int argc, char * argv[]);
private:
    
};

#endif



